#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 14/11/2018 10:14 AM
"""

import unittest

import requests


class RequestsTests(unittest.TestCase):

    def test_form_post(self):
        """
        Content-Type in the header is application/x-www-form-urlencoded.
        :return:
        """
        r = requests.post('https://httpbin.org/post',
                          data={'key1': 'value1', 'key2': 'value2'})
        print(r.text)

    def test_json_post(self):
        """
        NOTE: the json parameter is ignored if either data or files is passed.
        AND change the Content-Type in the header to application/json.
        :return:
        """
        r = requests.post('https://httpbin.org/post',
                          json={'key1': 'value1', 'key2': 'value2'})
        print(r.text)
        print(r.status_code)
        print(r.headers.get('content-type'))

        # 判断response是否成功
        if r.status_code == requests.codes.ok:
            print('response ok.')

    def test_basic_auth_request(self):
        """
        提供用户名，密码
        :return:
        """
        requests.get('https://api.github.com/user', auth=('user', 'pass'))


if __name__ == '__main__':
    unittest.main()
