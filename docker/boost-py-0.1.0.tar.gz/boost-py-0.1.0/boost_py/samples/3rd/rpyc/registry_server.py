#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
UDP-based registry server.
The server listens to UDP broadcasts and answers them. Useful in local networks, were broadcasts are allowed;

TCP-based registry server.
The server listens to a certain TCP port and answers requests. Useful when you need to cross routers in the network, since they block UDP broadcasts;

@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 18/5/2018 10:58 AM
"""

import argparse

from rpyc.utils.registry import REGISTRY_PORT, DEFAULT_PRUNING_TIMEOUT
from rpyc.utils.registry import UDPRegistryServer, TCPRegistryServer
from rpyc.lib import setup_logger

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='rpyc registry server', add_help=True)
    parser.add_argument('--mode', action='store', default='TCP', choices=['TCP', 'UDP'], dest='mode',
                        help='Serving mode')
    parser.add_argument('--host', action='store', default='', dest='host',
                        help='The registry server deploy host')
    parser.add_argument('--port', action='store', type=int, default=REGISTRY_PORT, dest='port',
                        help='The UDP/TCP listener port')
    parser.add_argument('--timeout', action='store', type=int, default=DEFAULT_PRUNING_TIMEOUT, dest='timeout',
                        help='Set a custom pruning timeout (in seconds)')
    args = parser.parse_args()
    mode = args.mode
    host = args.host
    port = args.port
    timeout = args.timeout

    if mode == 'TCP':
        if host == '':
            host = '127.0.0.1'
        server = TCPRegistryServer(host=host, port=port, pruning_timeout=timeout)
    elif mode == 'UDP':
        if host == '':
            host = '0.0.0.0'
        server = UDPRegistryServer(host=host, port=port, pruning_timeout=timeout)

    setup_logger()
    server.start()
