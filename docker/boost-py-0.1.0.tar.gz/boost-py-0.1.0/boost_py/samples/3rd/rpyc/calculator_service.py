#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse

import rpyc
from rpyc.utils.server import ThreadedServer


class CalculatorService(rpyc.Service):

    ALIASES = ['CALCULATOR', 'CAL']

    def exposed_add(self, a, b):
        print('executing add')
        return a + b

    def exposed_sub(self, a, b):
        return a - b

    def exposed_mul(self, a, b):
        return a * b

    def exposed_div(self, a, b):
        return a / b

    def foo(self):
        print('foo')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='calculator service', add_help=True)
    parser.add_argument('--host', action='store', default='127.0.0.1', dest='host', help='host to deploy')
    parser.add_argument('--port', action='store', default=51002, type=int, dest='port', help='port to deploy')

    args = parser.parse_args()
    host = args.host
    port = args.port

    server = ThreadedServer(CalculatorService,
                            port=port,
                            auto_register=False)
    server.start()
