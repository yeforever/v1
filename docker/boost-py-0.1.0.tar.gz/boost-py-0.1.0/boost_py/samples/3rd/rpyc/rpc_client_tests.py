#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import unittest
import rpyc


class RpcClientTests(unittest.TestCase):

    def test_connect_by_service(self):

        print('test_connect_by_service')

        service_name = 'CALCULATOR'

        c = rpyc.connect_by_service(service_name)
        print(c.root.add(1, 2))

    def test_connect(self):
        conn = rpyc.connect('127.0.0.1', 51000)
        conn.root.add_job()
