#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 13/9/2018 11:23 AM
"""

from datetime import timedelta

from celery import Celery
from kombu import Exchange, Queue


# 新建celery_server
celery_server = Celery('celery_server',
                       broker='redis://localhost:6379/0',
                       backend='redis://localhost',
                       include=['samples.3rd.celery.backend_server'])
# 配置celery_server
celery_server.conf.update(
        result_expires=3600,
        timezone='Asia/Shanghai',
        task_queues=(
            Queue('notify_queue', Exchange('priority', type='direct'), routing_key='notify_queue'),
            Queue('cal_queue', Exchange('priority', type='direct'), routing_key='cal_queue'),
            Queue('schedule_queue', Exchange('priority', type='direct'), routing_key='schedule_queue')
        ),
        task_routes={
            'notify_queue.tasks.*': {'queue': 'notify_queue', 'routing_key': 'notify_queue'},
            'cal_queue.tasks.*': {'queue': 'cal_queue', 'routing_key': 'cal_queue'},
            'schedule_queue.tasks.*': {'queue': 'schedule_queue', 'routing_key': 'schedule_queue'}
        },
        beat_schedule={
            'schedule-every-5-seconds': {
                'task': 'schedule_queue.tasks.send_mail',
                'schedule': timedelta(seconds=10),
                'args': ()
            }
        }
)

