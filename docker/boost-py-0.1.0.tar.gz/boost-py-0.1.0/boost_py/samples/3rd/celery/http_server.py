#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
sanic http server
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 28/4/2018 4:06 PM
"""

from sanic import Sanic
from sanic.response import json

from ..celery.celery_server import celery_server


# 新建sanic server
sanic_http_server = Sanic()


@sanic_http_server.post('/samples/celery-server/send-mail')
async def send_mail(request):
    """ 往任务队列发送任务（发送电子邮件），立即返回结果

    :param request:
    :return:
    """
    celery_server.send_task('notify_queue.tasks.send_mail', [{'to': 'guu'}])

    return json(body={'err_code': 0}, status=200)


@sanic_http_server.post('/samples/celery-server/do-add')
async def do_add(request):
    """ 往任务队列发送任务（执行相加逻辑），立即返回结果

    :param request:
    :return:
    """
    celery_server.send_task('cal_queue.tasks.add', [1, 2])

    return json(body={'err_code': 0}, status=200)


if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, workers=2, debug=True, access_log=True)
