#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/9/2018 2:27 PM
"""

from ..celery.celery_server import celery_server

# celery_server.send_task('notify_queue.tasks.send_mail', [{'to': 'guu'}])

celery_server.send_task('cal_queue.tasks.add', [1, 2])

# celery_server.send_task('notify_queue.tasks.alert')
