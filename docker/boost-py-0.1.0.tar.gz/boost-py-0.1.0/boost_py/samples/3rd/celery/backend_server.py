#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
backend server - 放业务相关的逻辑
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 23/4/2018 3:10 PM
"""

from time import sleep

from ..celery.celery_server import celery_server


@celery_server.task(name='notify_queue.tasks.send_mail')
def send_mail_once(mail_info=None):
    mail_info = mail_info or {'to': 'xx'}
    print('开始发送邮件, to %s...' % mail_info['to'])
    for i in range(2):
        print('发送中 ...')
        sleep(1)
    return '发送完成'


@celery_server.task(name='notify_queue.tasks.alert')
def alert():
    print('alerting ...')
    return 'alert完成'


@celery_server.task(name='cal_queue.tasks.add')
def add(x, y):
    print('开始执行 add {x} and {y} ...'.format(x=x, y=y))
    for i in range(2):
        print('计算中 ...')
        sleep(1)
    return '计算结束，结果是 {result}'.format(result=x+y)


@celery_server.task(name='schedule_queue.tasks.send_mail')
def send_mail_periodically(mail_info=None):
    mail_info = mail_info or {'to': 'xx'}
    print('开始发送邮件, to %s...' % mail_info['to'])
    for i in range(2):
        print('发送中 ...')
        sleep(1)
    return '发送完成'
