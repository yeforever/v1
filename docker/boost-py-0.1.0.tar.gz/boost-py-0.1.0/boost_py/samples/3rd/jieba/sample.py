#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
jieba支持三种分词模式：
1. 精确模式（默认）：试图将句子最精确地切开，适合文本分析；
2. 全模式：把句子中所有的可以成词的词语都扫描出来, 速度非常快，但是不能解决歧义；
3. 搜索引擎模式：在精确模式的基础上，对长词再次切分，提高召回率，适合用于搜索引擎分词。

@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 10/8/2018 11:07 AM
"""

import jieba

# 加载自定义词典
jieba.load_userdict('userdict.txt')

text_content = '2017年，随着电视剧《白鹿原》热播，白鹿原这个独具西安特色的文化IP成为资本追逐的对象，' \
               '仅仅200多平方公里的白鹿原上就分布了至少6家以“白鹿原”为主题的特色乡村旅游项目，' \
               '分别是白鹿仓景区、白鹿原生态文化观光园、白鹿原影视城、白鹿原民俗村、簸箕掌民俗村、白鹿古镇。' \
               '这些项目无一不将白鹿原文化作为卖点，游客实际体验后却发现，这些大都是以古建筑为特征，景区文化元素基本雷同——主营业务都是陕西小吃。' \
               '上游新闻记者在白鹿原实地采访看到，除了白鹿原影视城，由于各景区的白热化竞争以及客源抢夺，6家特色乡村旅游项目，有的已关门大吉，有的或勉强维持。'

text_content_2 = '李小福是创新办主任也是云计算方面的专家; 什么是八一双鹿' \
            '例如我输入一个带“韩玉赏鉴”的标题，在自定义词库中也增加了此词为N类' \
            '「台中」正確應該不會被切開。mac上可分出「石墨烯」；此時又可以分出來凱特琳了。'

seg_list = jieba.cut(text_content_2, cut_all=False)
print('Default Mode: ' + '/ '.join(seg_list))  # 精确模式

seg_list = jieba.cut(text_content_2, cut_all=True)
print('Full Mode: ' + '/ '.join(seg_list))  # 全模式

seg_list = jieba.cut_for_search(text_content_2)  # 搜索引擎模式
print(', '.join(seg_list))
