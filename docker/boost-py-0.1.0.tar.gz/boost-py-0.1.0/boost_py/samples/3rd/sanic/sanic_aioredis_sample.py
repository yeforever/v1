#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

from sanic import Sanic, response
import aioredis

app = Sanic(__name__)


@app.route('/')
async def handle(request):
    async with request.app.redis_pool.get() as redis:
        await redis.set('test-my-key', 'value')
        val = await redis.get('test-my-key')
    return response.text(val.decode('utf-8'))


@app.listener('before_server_start')
async def before_server_start(app, loop):
    print('create redis pool')
    app.redis_pool = await aioredis.create_pool(
        ('localhost', 6379),
        minsize=5,
        maxsize=10,
        loop=loop
    )


@app.listener('after_server_stop')
async def after_server_stop(app, loop):
    print('close redis pool')
    app.redis_pool.close()
    await app.redis_pool.wait_closed()


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8000, debug=True, workers=2)