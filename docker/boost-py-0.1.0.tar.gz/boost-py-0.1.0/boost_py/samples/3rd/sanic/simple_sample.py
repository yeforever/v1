#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

from sanic import Sanic
from sanic.response import json
from sanic.response import text

app = Sanic()

@app.post('/post/form')
async def handle_form_post(request):
    # 处理以form表单形式提交的post请求
    print('POST request - {}'.format(request.form))
    return json({"msg": "xxx"})

@app.post('/post/json')
async def handle_json_post(request):
    # 处理以json形式提交的post请求
    print('POST request - {}'.format(request.json))
    return json({"msg": "xxx"})

@app.get('/get')
async def handle_get(request):
    # 处理get请求
    print('GET request - {}'.format(request.args))
    return json({"msg": "xxx"})

####################
# 解析get请求url中参数

@app.route('/tag/<tag>')
async def tag_handler(request, tag):
    return text('Tag - {}'.format(tag))

@app.route('/number/<integer_arg:int>')
async def integer_handler(request, integer_arg):
    return text('Integer - {}'.format(integer_arg))

@app.route('/number/<number_arg:number>')
async def number_handler(request, number_arg):
    return text('Number - {}'.format(number_arg))

@app.route('/person/<name:[A-z]+>')
async def person_handler(request, name):
    return text('Person - {}'.format(name))

@app.route('/folder/<folder_id:[A-z0-9]{0,4}>')
async def folder_handler(request, folder_id):
    return text('Folder - {}'.format(folder_id))


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8000)