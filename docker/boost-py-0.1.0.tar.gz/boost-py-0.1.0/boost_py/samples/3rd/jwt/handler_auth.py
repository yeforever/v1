#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
JSON Web Token auth for Tornado

@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

import jwt

AUTHORIZATION_HEADER = 'Authorization'
AUTHORIZATION_METHOD = 'bearer'
SECRET_KEY = "my_secret_key"
AUTHORIZTION_ERROR_CODE = 401

jwt_options = {
    'verify_signature': True,
    'verify_exp': True,
    'verify_nbf': False,
    'verify_iat': True,
    'verify_aud': False
}


def is_valid_header(parts):
    """
        Validate the header
    :param parts:
    :return:
    """
    if parts[0].lower() != AUTHORIZATION_METHOD:
        return False
    elif len(parts) == 1:
        return False
    elif len(parts) > 2:
        return False

    return True


def return_header_error(handler):
    """
        Return authorization header error
    :param handler:
    :return:
    """
    return_auth_error(handler, 'invalid header authorization')


def return_auth_error(handler, message):
    """
        Return authorization error
    :param handler:
    :param message:
    :return:
    """
    handler._transforms = []
    handler.set_status(AUTHORIZTION_ERROR_CODE)
    handler.write(message)
    handler.finish()


def jwt_auth(handler_class):
    """
        Tornado JWT Auth Decorator
    :param handler_class:
    :return:
    """
    def wrap_execute(handler_execute):

        def require_auth(handler, kwargs):

            auth = handler.request.headers.get(AUTHORIZATION_HEADER)
            if auth:
                parts = auth.split()

                if not is_valid_header(parts):
                    return_header_error(handler)

                token = parts[1]
                try:
                    jwt.decode(
                            token,
                            SECRET_KEY,
                            options=jwt_options
                    )
                except Exception as err:
                    return_auth_error(handler, str(err))

            else:
                handler._transforms = []
                handler.write('missing authorization')
                handler.finish()

            return True

        def _execute(self, transforms, *args, **kwargs):

            try:
                require_auth(self, kwargs)
            except Exception:
                return False

            return handler_execute(self, transforms, *args, **kwargs)

        return _execute

    handler_class._execute = wrap_execute(handler_class._execute)
    return handler_class
