#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 15/6/2018 10:34 AM
"""


def factorial(n):
    """ 递归实现n的阶乘n!

    :param n:
    :return:
    """
    return 1 if n < 2 else n * factorial(n-1)