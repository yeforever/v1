#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 25/7/2018 11:04 AM
"""

import unittest


class SortTests(unittest.TestCase):
    """

    """
    def test_sort_list_ele(self):
        """ 对列表排序（根据列表元素里某个字段）

        :return:
        """
        print('sort by age')
        list_1 = [
            {
                'name': 'dd',
                'age': 40
            }, {
                'name': 'aa',
                'age': 10
            }, {
                'name': 'bb',
                'age': 20
            }, {
                'name': 'cc',
                'age': 30
            }, {
                'name': 'xx',
                'age': 1
            }
        ]
        print(sorted(list_1, key=lambda ele: ele['age'], reverse=True))

        print('sort by age and score')
        list_2 = [
            {
                'name': 'dd',
                'age': 40,
                'score': 80
            }, {
                'name': 'aa',
                'age': 40,
                'score': 90
            }, {
                'name': 'bb',
                'age': 20,
                'score': 50
            }, {
                'name': 'cc',
                'age': 30,
                'score': 80
            }, {
                'name': 'xx',
                'age': 20,
                'score': 80
            }
        ]
        print(sorted(list_2, key=lambda ele: ele['age']+ele['score'], reverse=True))
        print(list_2)

        print('sort by post_time desc and pos asc')
        list_3 = [
            {
                'article_title': 'a1',
                'post_time': 9999,
                'pos': 4
            },
            {
                'article_title': 'a2',
                'post_time': 9999,
                'pos': 3
            },
            {
                'article_title': 'a3',
                'post_time': 9999,
                'pos': 1
            },
            {
                'article_title': 'a4',
                'post_time': 8888,
                'pos': 5
            },
            {
                'article_title': 'a4',
                'post_time': 8888,
                'pos': 4
            }
        ]

if __name__ == '__main__':
    unittest.main()
