#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""


class Person(object):

    def __init__(self, name, age):
        self.name = name
        self.age = age
        self._a = "a"
        self.__b = "b"


class Student(Person):

    def __init__(self, grade):
        self.grade = grade

person = Person(name="Pony", age=11)
print(person.name)
print(person._a)
