#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

import time
import functools


def log(func):
    @functools.wraps(func)
    def wrapper(*args, **kw):
        print("call %s():" % func.__name__)
        return func(*args, **kw)
    return wrapper


def log_with_param(name):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kw):
            print("call %s():" % func.__name__)
            print("name is %s" % name)
            return func(*args, **kw)
        return wrapper
    return decorator

@log
def test_1():
    print(int(time.time()))


@log_with_param(name="pony")
def test_2():
    print(int(time.time()))

test_1()
test_2()