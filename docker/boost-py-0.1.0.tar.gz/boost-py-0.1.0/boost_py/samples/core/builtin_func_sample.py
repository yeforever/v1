#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Python built-in Functions（内置函数）示例
    - globals() 以字典类型返回当前位置的全部局部变量
    - locals()

@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

import unittest


class BuiltinFuncTests(unittest.TestCase):

    def test_locals(self):
        """

        :return:
        """
        pass

    def test_globals(self):
        """

        :return:
        """
        pass

    def test_zip(self):
        """ 测试 zip(*iterables)

        :return:
        """
        x = [1, 2, 3]
        y = [4, 5, 6]
        zipped = zip(x, y)
        print(list(zipped))  # [(1, 4), (2, 5), (3, 6)]

        a = [1, 2, 3]
        b = [4, 5]
        zipped = zip(a, b)
        print(list(zipped))  # [(1, 4), (2, 5)]

    def test_abs(self):
        print(abs(-1))  #1

    def test_all(self):
        print(all([1, 2]))  # true 所有元素迭代是真实的
        print(all([]))      # true 可迭代为空
        print(all(['']))    # false 所有元素迭代不是真实的

    def test_any(self):
        print(any([1, 2]))  # true 所有元素迭代是真实的
        print(any([]))      # false 可迭代为空
        print(any(['']))    # false 所有元素迭代不是真实的

    def test_ascii(self):
        print(ascii(1))     # '1' 传入一个object返回一个str

    def test_bin(self):
        print(bin(10))     # '0b1010' 返回一个整数 int 或者长整数 long int 的二进制表示。

    def test_bool(self):
        # 函数用于将给定参数转换为布尔类型，如果没有参数，返回 False。
        print(bool())   # False
        print(bool(0))  # False
        print(bool(1))  # True
        print(issubclass(bool, int))  # True bool 是 int 子类

    def test_bytearray(self):
        """
        bytearray([source[, encoding[, errors]]])
            如果 source 为整数，则返回一个长度为 source 的初始化数组；
            如果 source 为字符串，则按照指定的 encoding 将字符串转换为字节序列；
            如果 source 为可迭代类型，则元素必须为[0 ,255] 中的整数；
            如果 source 为与 buffer 接口一致的对象，则此对象也可以被用于初始化 bytearray。
            如果没有输入任何参数，默认就是初始化数组为0个元素。
        :return:新字节数组
        """
        print(bytearray())  #bytearray(b'')
        print(bytearray([1,2,3]))   #bytearray(b'\x01\x02\x03')
        print(bytearray('runoob', 'utf-8'))  #bytearray(b'runoob')

    def test_bytes(self):
        """
        bytes([source[, encoding[, errors]]])
            如果 source 为整数，则返回一个长度为 source 的初始化数组；
            如果 source 为字符串，则按照指定的 encoding 将字符串转换为字节序列；
            如果 source 为可迭代类型，则元素必须为[0 ,255] 中的整数；
            如果 source 为与 buffer 接口一致的对象，则此对象也可以被用于初始化 bytearray。
            如果没有输入任何参数，默认就是初始化数组为0个元素。
        :return:新的 bytes 对象
        """
        print(bytes([1, 2, 3, 4]))  #b'\x01\x02\x03\x04'
        print(bytes('hello','ascii'))   #b'hello'

    def test_callable(self):
        """
        callable(object)
        函数返回 True
        类返回 True
        没有实现 __call__, 返回 False
        实现 __call__, 返回 True
        :return:可调用返回 True，否则返回 False。
        """
        print(callable(0))  #False
        print(callable("runoob"))   #False

        def add(a, b):
            return a+b
        print(callable(add))    #True

        class A:
            def method(self):
                return 0
        print(callable(A))  #True

        a = A()
        print(callable(a))    #False

        class B:
            def __call__(self):
                return 0
        b = B()
        print(callable(b))  #True

    def test_chr(self):
        """
        chr(i)i -- 可以是10进制也可以是16进制的形式的数字。
        :return:当前整数对应的ascii字符。
        """
        print(chr(0x31))    #1
        print(chr(49))  #1

    def test_classmethod(self):
        """

        :return:函数的类方法。
        """
        class A(object):
            bar = 1

            def func1(self):
                print('foo')

            @classmethod
            def func2(cls):
                print('func2')
                print(cls.bar)
                cls().func1()  # 调用 foo 方法
        print(classmethod(A))

    def test_compile(self):
        """
        compile(source, filename, mode[, flags[, dont_inherit]])
            source -- 字符串或者AST（Abstract Syntax Trees）对象。。
            filename -- 代码文件名称，如果不是从文件读取代码则传递一些可辨认的值。
            mode -- 指定编译代码的种类。可以指定为 exec, eval, single。
            flags -- 变量作用域，局部命名空间，如果被提供，可以是任何映射对象。。
            flags和dont_inherit是用来控制编译源码时的标志
        :return:表达式执行结果
        """
        str1 = "for i in range(0,10): print(i)"
        print(compile(str1, '', 'exec'))     # 编译为字节代码对象
        exec(compile(str1, '', 'exec'))     #0123456789
        str2 = "3 * 4 + 5"
        a = compile(str2, '', 'eval')
        print(eval(a))     #17

    def test_complex(self):
        print(complex())

    def test_delattr(self):
        print(delattr())

    def test_dict(self):
        print(dict())

    def test_dir(self):
        print(dir())

    def test_divmod(self):
        print(divmod())

    def test_enumerate(self):
        print(enumerate())

    def test_eval(self):
        print(eval())

    def test_exec(self):
        print(exec())

    def test_filter(self):
        print(filter())

    def test_float(self):
        print(float())

    def test_format(self):
        print(format())

    def test_frozenset(self):
        print(frozenset())

    def test_getattr(self):
        print(getattr())

    def test_hasattr(self):
        print(hasattr())

    def test_hash(self):
        print(hash())

    def test_help(self):
        print(help())

    def test_hex(self):
        print(hex())

    def test_id(self):
        print(id())

    def test_input(self):
        print(input())

    def test_int(self):
        print(int())

    def test_isinstance(self):
        print(isinstance())

    def test_issubclass(self):
        print(issubclass())

    def test_iter(self):
        print(iter())

    def test_len(self):
        print(len())

    def test_list(self):
        print(list())

    def test_locals(self):
        print(locals())

    def test_map(self):
        print(map())

    def test_max(self):
        print(max())

    def test_memoryview(self):
        print(memoryview())

    def test_min(self):
        print(min())

    def test_next(self):
        print(next())

    def test_object(self):
        print(object())

    def test_oct(self):
        print(oct())

    def test_open(self):
        print(open())

    def test_ord(self):
        print(ord())

    def test_pow(self):
        print(pow())

    def test_print(self):
        print(print())

    def test_property(self):
        print(property())

    def test_range(self):
        print(range())

    def test_repr(self):
        print(repr())

    def test_reversed(self):
        print(reversed())

    def test_round(self):
        print(round())

    def test_set(self):
        print(set())

    def test_setattr(self):
        print(setattr())

    def test_slice(self):
        print(slice())

    def test_sorted(self):
        print(sorted())

    def test_staticmethod(self):
        print(staticmethod())

    def test_str(self):
        print(str())

    def test_sum(self):
        print(sum())

    def test_super(self):
        print(super())

    def test_tuple(self):
        print(tuple())

    def test_type(self):
        print(type())

    def test_vars(self):
        print(vars())

    def test___import__(self):
        print(__import__())





if __name__ == '__main__':
    unittest.main()
