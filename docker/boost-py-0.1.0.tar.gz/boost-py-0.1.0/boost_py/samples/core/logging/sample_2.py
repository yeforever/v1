#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: wpronet@163.com
@time: 7/8/17 9:24 PM
"""

import logging

# create logger
logging.basicConfig(level=logging.DEBUG,
                    format="%(asctime)s %(filename)s[line:%(lineno)d] [%(levelname)s] %(message)s",
                    datefmt="%a, %d %b %Y %H:%M:%S",
                    filename="sample_2.log",
                    filemode="a")
logger = logging.getLogger(__name__)

print(logger)

logger.info('info message')
