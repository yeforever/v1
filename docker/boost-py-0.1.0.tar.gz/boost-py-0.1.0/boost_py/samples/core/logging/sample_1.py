#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
logging里module-level functions示例代码

@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

import logging

logging.basicConfig(level=logging.DEBUG,
                    format='%(asctime)s %(filename)s[line:%(lineno)d] [%(levelname)s] %(message)s',
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='sample_1.log',
                    filemode='a')

# 日志级别大小关系为：CRITICAL > ERROR > WARNING > INFO > DEBUG > NOTSET
logging.error('This is error message name: %s, sex: %s', 'jack', 'mail')
logging.warning('This is warning message')
logging.info('This is info message')
logging.debug('This is debug message')
