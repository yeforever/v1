#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 27/6/2018 10:37 AM
"""

from urllib import parse as url_parser
from pprint import pprint
import unittest


class UrllibSamples(unittest.TestCase):

    url_1 = 'dubbo%3A%2F%2F10.4.5.3%3A20880%2Fcom.welab.authority.service.AuthorityService%3Fanyhost%3Dtrue%26application%3Dwelab-authority%26dubbo%3D2.5.7'

    def test_url_parser(self):
        """ url解码

        :return:
        """
        print('=========== 原始url')
        print(self.url_1)

        print('=========== url解码(unquote)')
        unquoted_url = url_parser.unquote(self.url_1)
        print(unquoted_url)

        print('=========== 解析url')
        parse_result = url_parser.urlparse(unquoted_url)
        print(parse_result)

        print('=========== 获取url里的query参数')
        query_dict = url_parser.parse_qs(parse_result.query)
        pprint(query_dict)

        print('=========== 获取信息')
        ip = parse_result.netloc
        application = query_dict.get('application', [])
        print(ip)
        print(application)


if __name__ == '__main__':
    unittest.main()
