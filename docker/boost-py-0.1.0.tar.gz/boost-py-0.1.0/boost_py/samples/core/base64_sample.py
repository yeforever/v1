#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

import base64

from boost_py.helpers.core.base64_helper import Base64Helper

# 将3字节的二进制数据编码为4字节的文本数据
print(base64.b64encode(b'abcd'))  # 输出 b'YWJjZA=='

# 将文本数据解码为二进制数据
print(base64.b64decode('YWJjZA=='))  # 输出 b'abcd'

# 将去掉 = 的文本数据解码为二进制数据
print(Base64Helper.safe_b64decode('YWJjZA'))  # 输出 b'abcd'

