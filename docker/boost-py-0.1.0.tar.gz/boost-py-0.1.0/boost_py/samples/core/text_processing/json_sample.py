#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 10/8/2018 7:02 AM
"""

import json


s = "{'name': 'xxx'}"
print(json.loads(s))  # 抛 json.decoder.JSONDecodeError

ss = '{"name": "xxx"}'
print(json.loads(ss))
