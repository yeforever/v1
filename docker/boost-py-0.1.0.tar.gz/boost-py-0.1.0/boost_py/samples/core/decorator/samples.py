#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 12/6/2018 4:30 PM
"""

from .decorators import logger, say_hello


@logger
def add(x, y):
    print('{} + {} = {}'.format(x, y, x+y))


@say_hello('china')
def chinese():
    print("我来自中国。")