#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 12/6/2018 4:30 PM
"""


def logger(func):

    def wrapper(*args, **kw):

        print('begin to run, {}'.format(func.__name__))

        func(*args, **kw)

        print('end run')

    return wrapper


def say_hello(contry):

    def wrapper(func):

        def deco(*args, **kwargs):
            if contry == 'china':
                print('你好!')
            elif contry == 'america':
                print('hello.')
            else:
                return

            func(*args, **kwargs)

        return deco
    return wrapper
