#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 3/7/2018 4:26 PM
"""

import time
from multiprocessing import Pool
from multiprocessing.context import TimeoutError


def do_work_1(x):
    return x*x


def do_work_2(x, y):
    print('work2 executing at %s' % str(time.time()))
    return x*x + y


def do_heavy_work_1(x):
    time.sleep(3)
    return x*x


def do_heavy_work_2(x, y):
    time.sleep(3)
    return x*x + y


def do_callback(param):
    print('callback executing at %s' % str(time.time()))
    print('param: ' + param)


def do_error_callback(param):
    print(param)

if __name__ == '__main__':
    with Pool(processes=5) as p:

        print('=== 测试1 ===')
        # print [0, 1, 4, 9]
        print(p.map(do_work_1, range(4)))

        print('=== 测试apply ===')
        # evaluate "do_work_2(2, 1)" synchronously,
        # will block until the result is ready, func is only executed in one of the workers of the pool.
        print(p.apply(do_work_2, (2, 1)))

        print('=== 测试apply_async ===')
        # evaluate "do_work_2(20, 1)" asynchronously, runs in *only* one process
        res = p.apply_async(do_work_2, (20, 1),
                            callback=do_callback('callback executing'),
                            error_callback=do_error_callback('execute error callback'))
        print(res.get(timeout=1))

        print('=== 测试func和callback哪个先执行 ===')
        res = p.apply_async(do_work_2, (2, 1),
                            callback=do_callback('callback executing'))
        print(res.get(timeout=1))

        print('=== 测试4 ===')
        # launching multiple evaluations asynchronously *may* use more processes
        multiple_results = [p.apply_async(do_heavy_work_2, (i, 1),
                                          callback=do_callback('execute callback'),
                                          error_callback=do_error_callback('execute error callback')) for i in range(10)]
        print([res.get(timeout=5) for res in multiple_results])

        print('=== 测试apply_async执行超时 ===')
        res = p.apply_async(do_heavy_work_2, (10, 1))
        try:
            print(res.get(timeout=1))
        except TimeoutError:
            print('timeout..')


