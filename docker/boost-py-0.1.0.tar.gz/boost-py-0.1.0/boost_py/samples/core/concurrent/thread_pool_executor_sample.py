#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
示例：多线程爬取网页

concurrent.futures.ThreadPoolExecutor

@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 18/7/2018 5:20 PM
"""

from concurrent.futures import ThreadPoolExecutor, as_completed
import urllib.request

URLS = ['http://www.baidu.com/',
        'http://www.sina.com/']


def load_url(url, timeout):
    """ 读取网页内容

    :param url:
    :param timeout:
    :return:
    """
    with urllib.request.urlopen(url, timeout=timeout) as conn:
        return conn.read()

# We can use a with statement to ensure threads are cleaned up promptly
with ThreadPoolExecutor(max_workers=5) as executor:
    # Start the load operations and mark each future with its URL
    future_to_url = {executor.submit(load_url, url, 60): url for url in URLS}
    for future in as_completed(future_to_url):
        url = future_to_url[future]
        try:
            data = future.result()
        except Exception as exc:
            print('%r generated an exception: %s' % (url, exc))
        else:
            print('%r page is %d bytes' % (url, len(data)))
