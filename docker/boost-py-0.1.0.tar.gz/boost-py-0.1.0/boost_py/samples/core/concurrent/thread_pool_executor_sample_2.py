#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 19/7/2018 9:39 AM
"""

from time import sleep
from concurrent.futures import ThreadPoolExecutor, as_completed
import urllib.request

URLS = [
    'www.1.com',
    'www.2.com',
    'www.3.com',
    'www.4.com',
    'www.5.com'
]


def load_url(url):
    """ 读取网页内容

    :param url:
    :return:
    """
    sleep(3)
    print('url: %s' % url)

print('实验1')
with ThreadPoolExecutor(max_workers=5) as executor:
    {executor.submit(load_url, url): url for url in URLS}

    print('task submit')

print('实验2')
# We can use a with statement to ensure threads are cleaned up promptly
with ThreadPoolExecutor(max_workers=5) as executor:
    # Start the load operations and mark each future with its URL
    future_to_url = {executor.submit(load_url, url): url for url in URLS}
    for future in as_completed(future_to_url):
        url = future_to_url[future]
        try:
            data = future.result()
        except Exception as exc:
            print('%r generated an exception: %s' % (url, exc))

    print('finish')
