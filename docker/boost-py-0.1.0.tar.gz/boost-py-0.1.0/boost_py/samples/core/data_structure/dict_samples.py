#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

import unittest


class DictSamples(unittest.TestCase):

    def test_update1(self):
        """
            Python 字典 update() 函数把字典dict2的键/值对更新到dict里
        :return:
        """
        dict = {"Name": "Runoob", "Age": 7}
        dict2 = {"Sex": "female", "Age": 10}
        dict.update(dict2)

        print("更新字典 dict : ", dict)

    def test_update2(self):
        list = [
            {
                'code': 1,
                'name': 'xx',
                'count': 1
            },
            {
                'code': 2,
                'name': 'yy',
                'count': 2
            }
        ]
        for item in list:
            if item['code'] == 1:
                item['count'] += 1

        from pprint import pprint
        pprint(list)


if __name__ == '__main__':
    unittest.main()
