#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

import hmac
import base64

# key is a bytes or bytearray object giving the secret key
hmac_obj = hmac.new(key="54fd4a6a27d57674b696893989ed7b5e".encode(), msg="1234567abcdefg".encode(), digestmod="sha256")
# 获得msg字节的摘要
msg_digest = hmac_obj.digest()
# 获得签名字符串
string_signed = base64.b64encode(msg_digest).decode()

print(string_signed)