#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 5/9/2018 2:31 PM
"""

from functools import wraps

from sanic.response import json


def response_ok(body={'err_code': 0, 'err_msg': ''}):
    """ service response ok

    :param body:
    :return:
    """
    return json(body=body, status=200)


def response_error(body={'err_code': 1, 'err_msg': ''}):
    """ service response error

    :param body:
    :return:
    """
    return json(body=body, status=500)


def get_param(request, param_name, default=None):
    """ 获得请求get & post中的参数

    :param request:
    :param param_name:
    :param default:
    :return:
    """
    param_value = request.form.get(param_name)
    if param_value is not None:
        try:
            param_value = int(param_value)
            return param_value
        except ValueError:
            return param_value

    param_value = request.raw_args.get(param_name)
    if param_value is not None:
        try:
            param_value = int(param_value)
            return param_value
        except ValueError:
            return param_value

    try:
        request_data = request.json
        if request_data is not None and param_name in request_data:
            return request_data[param_name]
    except ValueError:
        pass

    return default


# def authorized():
#     def decorator(f):
#         @wraps(f)
#         async def decorated_function(request, *args, **kwargs):
#             # run some method that checks the request
#             # for the client's authorization status
#             is_authorized = check_request_for_authorization_status(request)
#
#             if is_authorized:
#                 # the user is authorized.
#                 # run the handler method and return the response
#                 response = await f(request, *args, **kwargs)
#                 return response
#             else:
#                 # the user is not authorized.
#                 return json({'status': 'not_authorized'}, 403)
#         return decorated_function
#     return decorator