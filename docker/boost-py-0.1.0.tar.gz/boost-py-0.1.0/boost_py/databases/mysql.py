#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

from peewee import *
from playhouse.pool import PooledMySQLDatabase


__all__ = ['get_pooled_db', 'get_db']


def get_pooled_db(database, max_connections=10, stale_timeout=300, timeout=10, **connect_kwargs):
    """
        get mysql pooled database instance

        The database can be instantiated with None as the database name if the database is not known until run-time.
        In this way you can create a database instance and then configure it elsewhere when the settings are known.
        This is called deferred initialization. To initialize a database that has been deferred, use the init() method.

    :param database: The name of the database or database file
    :param max_connections: Maximum number of connections. Provide None for unlimited.
    :param stale_timeout: Number of seconds to allow connections to be used.
    :param timeout: Number of seconds block when pool is full.
    By default peewee does not block when the pool is full but simply throws an exception.
    To block indefinitely set this value to 0.
    :param connect_kwargs: Arbitrary keyword arguments passed to database class.
    :return:
    """
    return PooledMySQLDatabase(database, max_connections=max_connections, stale_timeout=stale_timeout, timeout=timeout,
                               **connect_kwargs)


def get_db(database, **connect_kwargs):
    """
        get mysql database instance
    :return:
    """
    return MySQLDatabase(database, **connect_kwargs)
