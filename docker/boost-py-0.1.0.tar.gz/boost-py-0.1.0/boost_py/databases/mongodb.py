#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
It is a common mistake to create a new client for each request, which is very inefficient.

@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

from urllib.parse import quote_plus
import pymongo
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure
from pymongo.cursor import CursorType
from motor.motor_asyncio import AsyncIOMotorClient

from ..exceptions.db_exceptions import MongoConnectionError


class BaseMongo(object):

    @classmethod
    def get_client(cls, db_name, **db_config):
        """ 获得mongodb client实例

        :param db_name:
        :param db_config:
        :return:
        """
        host = db_config['host'] if 'host' in db_config else 'localhost'
        port = db_config['port'] if 'port' in db_config else 27011
        user = db_config['user'] if 'user' in db_config else ''
        password = db_config['password'] if 'password' in db_config else ''
        uri = 'mongodb://%s:%s@%s:%s/%s' % (quote_plus(user), quote_plus(password), host, port, db_name)
        client = MongoClient(uri)
        try:
            # The ismaster command is cheap and does not require auth.
            client.admin.command('ismaster')
            return client
        except ConnectionFailure:
            raise MongoConnectionError('MongoDB server not available')

    @classmethod
    def get_async_client(cls, db_name, **db_config):
        """ 获得mongodb client实例（支持async io）

        :param db_name:
        :param db_config:
        :return:
        """
        host = db_config['host'] if 'host' in db_config else 'localhost'
        port = db_config['port'] if 'port' in db_config else 27011
        user = db_config['user'] if 'user' in db_config else ''
        password = db_config['password'] if 'password' in db_config else ''
        uri = 'mongodb://%s:%s@%s:%s/%s' % (quote_plus(user), quote_plus(password), host, port, db_name)
        client = AsyncIOMotorClient(uri)
        return client


class BaseMongoCollection(object):

    DESCENDING = pymongo.DESCENDING
    ASCENDING = pymongo.ASCENDING

    def __init__(self, db_name, db_config, collection_name):
        self.db_name = db_name
        self.collection_name = collection_name
        self.client = BaseMongo.get_client(self.db_name, **db_config)

    def insert_one(self, document):
        """ insert one new document into mongodb

        :param document:
        :return:
        """
        result = self.client[self.db_name][self.collection_name].insert_one(document)
        return result.inserted_id

    def insert_many(self, documents):
        """ Insert an iterable of documents.

        :param documents:
        :return:
        """
        result = self.client[self.db_name][self.collection_name].insert_many(documents)
        return result.inserted_ids

    def find(self, query_filter=None, projection=None, *args, **kwargs):
        """ Returns an instance of Cursor corresponding to this query

        :param query_filter:
        :param projection:
        :return:
        """
        return self.client[self.db_name][self.collection_name].find(query_filter, projection, *args, **kwargs)

    def find_one(self, query_filter=None, *args, **kwargs):
        """ Returns a single document, or None if no matching document is found.

        :param query_filter:
        :param args:
        :param kwargs:
        :return: Returns a single document, or None if no matching document is found.
        """
        return self.client[self.db_name][self.collection_name].find_one(query_filter, *args, **kwargs)

    def update_one(self, query_filter, update, upsert=False):
        """ update one document

        :param query_filter:
        :param update:
        :param upsert:
        :return:
        """
        return self.client[self.db_name][self.collection_name].update_one(filter=query_filter, update=update, upsert=upsert)

    def update_many(self, query_filter, update, upsert=False):
        """ update many documents

        :param query_filter:
        :param update:
        :param upsert:
        :return:
        """
        return self.client[self.db_name][self.collection_name].update_many(filter=query_filter, update=update, upsert=upsert)

    def delete_one(self, filter, collation=None, session=None):
        """ Delete a single document matching the filter.

        :param filter:
        :param collation:
        :param session:
        :return:
        """
        return self.client[self.db_name][self.collection_name].delete_one(filter, collation, session)

    def delete_many(self, filter, collation=None, session=None):
        """ Delete one or more documents matching the filter.

        :param filter:
        :param collation:
        :param session:
        :return:
        """
        return self.client[self.db_name][self.collection_name].delete_many(filter, collation, session)

    def count(self, filter):
        """ Count the number of documents in this collection.

        :param filter:
        :return:
        """
        return self.client[self.db_name][self.collection_name].count(filter)

    # def __del__(self):
    #     self.client.close()

