#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
超时装饰器

示例：
@timeout_limit(5)
def func():
   pass

@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 15/6/2018 9:42 AM
"""

import signal


class TimeoutException(Exception):

    def __init__(self, error='Timeout waiting for response'):
        Exception.__init__(self, error)


def timeout_limit(timeout_time):

    def wraps(func):

        def handler(signum, frame):
            raise TimeoutException()

        def deco(*args, **kwargs):
            signal.signal(signal.SIGALRM, handler)
            signal.alarm(timeout_time)
            func(*args, **kwargs)
            signal.alarm(0)  # Disable the alarm
        return deco

    return wraps
