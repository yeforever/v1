#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
花费时间统计

@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 12/7/2018 6:23 PM
"""