#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 27/6/2018 2:54 PM
"""
import json

import requests
from urllib.parse import urlparse, quote


class WeiboOpenSdk(object):

    OPEN_WEIBO_HOST = 'https://api.weibo.com/2/'
    OPEN_WEIBO_HOST_2 = 'https://c.api.weibo.com/2/'
    ALPHABET = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'

    @classmethod
    def base62_decode(cls, string, alphabet=ALPHABET):
        """ Decode a Base X encoded string into the number

        :param alphabet:
        :return:
        """
        base = len(alphabet)
        strlen = len(string)
        num = 0

        idx = 0
        for char in string:
            power = (strlen - (idx + 1))
            num += alphabet.index(char) * (base ** power)
            idx += 1

        return num

    @classmethod
    def get_mid_from_url(cls, article_url) -> str:
        """ 从微博url中获取mid

        :param article_url:
        :return:
        """
        reverse_path = urlparse(article_url).path[::-1]
        slash_pos = reverse_path.find('/')
        mid = reverse_path[0:slash_pos][::-1]
        return mid

    @classmethod
    def get_id_from_mid(cls, mid: str) -> str:
        """ 将微博mid转换成id

        :param mid:
        :return:
        """
        section1 = str(cls.base62_decode(mid[0]))
        section2 = str(cls.base62_decode(mid[1:5]))
        section3 = str(cls.base62_decode(mid[5:]))

        section2 = '0' * (7 - len(section2)) + section2
        section3 = '0' * (7 - len(section3)) + section3

        return ''.join([section1, section2, section3])

    @classmethod
    def oauth_request(cls, api_url, access_token, need_auth_login=True, method='GET', params=None):
        """ 采用oauth授权方式请求

        :param api_url:
        :param access_token:
        :param need_auth_login:
        :param method:
        :param params:
        :return:
        """
        params = params or {}

        if need_auth_login:
            params['access_token'] = access_token

        if method == 'GET':
            _data = requests.get(api_url, params=params)
            return _data

        if method == 'POST':
            _data = requests.post(api_url, params=params)
            return _data

    @classmethod
    def statuses_count(cls, ids: list, access_token: str):
        """ 批量获取指定微博的转发数评论数(普通接口)

        :param ids:微博的id
        :param access_token:
        :return:
        """
        ids = ','.join(list(map(str, ids)))
        params = {
            'ids': ids  # 需要获取数据的微博ID，多个之间用逗号分隔，最多不超过100个
        }
        api_url = cls.OPEN_WEIBO_HOST + 'statuses/count.json'
        return cls.oauth_request(api_url, access_token, params=params)

    @classmethod
    def statuses_show(cls, id: int, access_token: str):
        """ 根据微博ID获取单条微博内容(普通接口)

        :param id:微博的id
        :param access_token:
        :return:
        """
        params = {
            'id': id
        }
        api_url = cls.OPEN_WEIBO_HOST + 'statuses/show.json'
        return cls.oauth_request(api_url, access_token, params=params)

    @classmethod
    def user_counts(cls, access_token, uids):
        """
            批量获取用户的粉丝数、关注数、微博数
        :param access_token:
        :param uids: 用户id
        :return:
        """
        params = {
            'uids': uids
        }
        api_url = cls.OPEN_WEIBO_HOST + 'users/counts.json'
        return cls.oauth_request(api_url, access_token, params=params)

    @classmethod
    def comments_show(cls, access_token, id, count=50, page=1):
        """
            根据微博ID返回某条微博的评论列表
        :param access_token:
        :param id: 需要查询的微博id
        :param count: 获取评论数
        :param page: 评论页数
        :return:
        """
        params = {
            "id": id,
            "count": count,
            "page": page
        }
        api_url = cls.OPEN_WEIBO_HOST + "comments/show.json"
        return cls.oauth_request(api_url, access_token, params=params)


    @classmethod
    def statuses_all(cls, access_token, id, count=1, page=1):
        """
            根据微博ID返回某条微博的评论列表
        :param access_token:
        :param id: 需要查询的微博id
        :param count: 获取评论数
        :param page: 评论页数
        :return:
        """
        params = {
            "id": id,
            "count": count,
            "page": page
        }
        api_url = cls.OPEN_WEIBO_HOST + "comments/show.json"
        return json.loads(cls.oauth_request(api_url, access_token, params=params).text)['comments'][0]['status']

    @classmethod
    def friendships_friends(cls, access_token, uid, count=50, page=1):
        """
            获取用户的关注列表,接口已经升级，必须是授权用户(普通接口，暂不使用)
        :param access_token:
        :param uids: 需要查询用户的uid
        :return:
        """
        params = {
            "uid": uid,
            "count": count,
            "page": page
        }
        api_url = cls.OPEN_WEIBO_HOST + "friendships/friends.json"
        return cls.oauth_request(api_url, access_token, params=params)

    @classmethod
    def friendships_friends_ids(cls, access_token, uid, count=10):
        """
            获取用户关注的用户UID列表,未授权无法获取(普通接口，暂不使用)
        :param access_token:
        :param uid: 需要查询的用户uid
        :param count: 单页返回记录条数
        :return:
        """
        params = {
            "uid": uid,
            "count": count
        }
        api_url = cls.OPEN_WEIBO_HOST_2 + "friendships/friends/ids.json"
        return cls.oauth_request(api_url, access_token, params=params)

    @classmethod
    def friendships_followers(cls, access_token, uid, count=5):
        """
            获取用户的粉丝列表，未授权，无法获取数据(普通接口，暂不使用)
        :param access_token:
        :param uid: 需要查询的用户UID
        :param count: 单页返回记录条数
        :return:
        """
        params = {
            "uid": uid,
            "count": count
        }
        api_url = cls.OPEN_WEIBO_HOST + "friendships/followers.json"
        return cls.oauth_request(api_url, access_token, params=params)

    @classmethod
    def friendships_followers_ids(cls, access_token, uid, count=5):
        """
            获取用户粉丝的用户UID列表,不是授权用户，无法获得信息(普通接口，暂不使用)
        :param access_token:
        :param uid: 需要查询用户的UID
        :param count: 单页返回记录条数
        :return:
        """
        params = {
            "uid": uid,
            "count": count
        }
        api_url = cls.OPEN_WEIBO_HOST + "friendships/followers/ids.json"
        return cls.oauth_request(api_url, access_token, params=params)

    @classmethod
    def search_topics(cls, access_token, q, count=5, page=1):
        """
            搜索某一话题下的微博，只返回最新的200条,应用接口访问权限受限制(普通接口，暂不使用)
        :param access_token:
        :param q:话题关键字，必须urlencode
        :param count:返回记录条数
        :param page:返回结果页码
        :return:
        """
        params = {
            "q": quote(q),
            "count": count,
            "page": page
        }
        api_url = cls.OPEN_WEIBO_HOST_2 + "search/topics.json"
        return cls.oauth_request(api_url, access_token, params=params)

    @classmethod
    def statuses_user_timeline_batch(cls, uids, access_token, count=20, page=1):
        """
            批量获取用户个人微博列表
        :param uids:查询用户的id,只返回最近200条结果
        :param access_token:
        :param count:单页返回记录条数，默认20
        :param page:页数
        :return:
        """
        params = {
            "uids": uids,
            "access_token": access_token,
            "count": count,
            "page": page
        }
        api_url = cls.OPEN_WEIBO_HOST_2 + "statuses/user_timeline_batch.json"
        return cls.oauth_request(api_url, access_token, params=params)

    @classmethod
    def tags_batch_other(cls, uids, access_token):
        """
            批量获取用户标签
        :param uids: 用户的uid
        :param access_token:
        :return:
        """
        params = {
            "uids": uids
        }
        api_url = cls.OPEN_WEIBO_HOST_2 + "tags/tags_batch/other.json"
        return cls.oauth_request(api_url, access_token, params=params)

    @classmethod
    def users_show_batch_other(cls, access_token, uids):
        """
            批量获取其他用户的基本信息
        :param access_token:
        :param uids: 用户的id
        :return:
        """
        params = {
            "uids": uids
        }
        api_url = cls.OPEN_WEIBO_HOST_2 + "users/show_batch/other.json"
        return cls.oauth_request(api_url, access_token, params=params)

    @classmethod
    def search_statuses_limited(cls, access_token, q, **kwargs):
        """
            搜索含某关键词的微博
        :param access_token:
        :param q: 	搜索的关键字( 不能包含{、}、“ 等特殊字符)。必须进行URLencode。
        :param ids: 搜索指定批量用户的微博，传用户UID，多个用~分隔
        :param sort: 排序方式，time：时间倒序、hot：热门度【设置此参数只会返回精选微博】、fwnum：按转发数倒序、cmtnum：评论数倒序，默认为time。
        :param starttime: 搜索范围起始时间，取值为时间戳，单位为秒。
        :param endtime: 搜索范围结束时间，取值为时间戳，单位为秒。
        :param page: 页码，默认为1。
        :param count:  	每页返回的数量，最小为10，最大50。（默认返回10条）
        :return:
        """
        params = {
            "q": quote(q),
            "ids": kwargs.get("ids", None),
            "sort": kwargs.get("sort", "time"),
            "starttime": kwargs.get("starttime", None),
            "endtime": kwargs.get("endtime", None),
            "page": kwargs.get("page", 1),
            "count": kwargs.get("count", 10)
        }
        api_url = cls.OPEN_WEIBO_HOST_2 + "search/statuses/limited.json"
        return cls.oauth_request(api_url, access_token, params=params)