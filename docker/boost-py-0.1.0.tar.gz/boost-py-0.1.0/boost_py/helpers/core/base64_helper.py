#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

import base64


class Base64Helper(object):
    """ Base64 helper

    """

    @classmethod
    def safe_b64decode(cls, s):
        """ 对去掉=的base64解码

        由于=字符也可能出现在Base64编码中，但=用在URL、Cookie里面会造成歧义，所以，很多Base64编码后会把=去掉：
            # 标准Base64:
            'abcd' -> 'YWJjZA=='
            # 自动去掉=:
            'abcd' -> 'YWJjZA'

        去掉=后怎么解码呢？
        因为Base64是把3个字节变为4个字节，所以，Base64编码的长度永远是4的倍数，因此，需要加上=把Base64字符串的长度变为4的倍数，就可以正常解码了。

        :return:
        """
        while len(s) % 4 != 0:
            s += '='
        return base64.b64decode(s)

if __name__ == '__main__':
    print(Base64Helper.safe_b64decode('YWJjZA'))  # b'abcd'
    print(base64.b64decode('YWJjZA=='))  # b'abcd'
