#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 4/6/2018 3:09 PM
"""

from urllib import parse as url_parser


class HttpHelper(object):

    @classmethod
    def parse_url_qs(cls, url: str):
        """ 解析获得url参数字典

        :param url:
        :return:
        """
        url_param_items = url_parser.parse_qs(url_parser.urlparse(url).query).items()
        url_params = {param_name: param_values[0] for param_name, param_values in url_param_items}
        return url_params

    @classmethod
    def build_qs(cls, params: dict=None):
        """ 构造query string

        :param params:
        :return:
        """
        params = params or {}
        qs = ''
        if isinstance(params, dict):
            keys = list(params.keys())
            for index, key in enumerate(keys):
                if index > 0:
                    qs += "&"
                qs += "%s=%s" % (key, params[key])
        return qs
