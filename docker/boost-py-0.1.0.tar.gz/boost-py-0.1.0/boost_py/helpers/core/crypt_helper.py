#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 14/4/2018 10:44 PM
"""

import os
from hashlib import sha256
from hmac import HMAC


class CryptHelper(object):
    """
        加密解密相关
    """

    @classmethod
    def encrypt_password(cls, password, salt=None):
        """ 加密密码

        :param password:
        :param salt:
        :return:
        """
        if salt is None:
            salt = os.urandom(8)  # 64 bits.

        assert 8 == len(salt)
        assert isinstance(salt, bytes)
        assert isinstance(password, str)

        if isinstance(password, str):
            password = password.encode('UTF-8')

        assert isinstance(password, bytes)

        result = password
        for i in range(10):
            result = HMAC(result, salt, sha256).digest()

        return salt + result

    @classmethod
    def validate_password(cls, hashed, input_password):
        """ 验证密码

        :param hashed:
        :param input_password:
        :return:
        """
        return hashed == cls.encrypt_password(input_password, salt=hashed[:8])