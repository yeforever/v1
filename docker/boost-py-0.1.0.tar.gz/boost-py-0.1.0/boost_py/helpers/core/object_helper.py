#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 23/7/2018 4:28 PM
"""


class ObjectHelper(object):

    @classmethod
    def to_str(cls, obj):
        """

        :param obj:
        :return:
        """
        return ','.join(['%s:%s' % item for item in obj.__dict__.items()])
