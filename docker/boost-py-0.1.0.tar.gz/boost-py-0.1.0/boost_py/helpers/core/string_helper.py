#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

import random
import uuid


class StringHelper(object):
    """ String helper

    """

    @classmethod
    def get_random_string(cls, length: int = 7):
        """ 生成随机的字符串

        :param length:
        :return:
        """
        return "+".join(random.sample("0123456789abcdefghijklmnopqrstevwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ", length))

    @classmethod
    def shorten(cls, text, length=25, indicator='...'):
        """ 当字符串长度超过某长度时，在字符串末尾添加字符如’...’

        :param text:
        :param length:
        :param indicator:
        :return:
        """
        if(len(text) > length):
            text = text[:length - len(indicator)] + indicator
        return text
