#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 27/4/2018 11:36 AM
"""


class NumberHelper(object):

    @classmethod
    def is_int(cls, val):
        """

        :param val:
        :return:
        """
        try:
            int(val)
            return True
        except ValueError:
            return False
