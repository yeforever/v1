#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
示例代码：

######################
    ## 当前时间 ##
######################
from datetime import datetime
import time
from boost_py.helpers.core.datetime_helper import DateTimeHelper

>>> datetime.now(DateTimeHelper.get_china_timezone())  # 当前时间对象
>>> datetime.now(DateTimeHelper.get_china_timezone()).strftime('%Y-%m-%d %H:%M:%S')  # 当前时间的字符串
>>> int(time.time())  # 当前时间戳（秒）

######################
    ## 当前日期 ##
######################
from datetime import date, timedelta
from boost_py.helpers.core.datetime_helper import DateTimeHelper

>>> date.today()  # 当前日期的实例
>>> date.today().strftime('%Y%m%d')  # 当前日期的字符串
>>> DateTimeHelper.parse_formatted_datetime(date.today().strftime('%Y%m%d'), '%Y%m%d')  # 当前日期的时间戳
>>> date.today().year | date.today().month | date.today().day
>>> date.today() + timedelta(days=1)  # 明天

############################################
    ## 根据当前获得过去的或者未来的某个日期 ##
############################################

# 7天前截止日期时间戳，比如今天是2019-02-15，则得到的值是1549555200，即2019-02-08 00:00:00
>>> seven_days_ago = DateTimeHelper.get_previous_datestamp(int(time.time()), 7)

# 7天前截止日期格式化字符串，如 '20190208'
>>> (date.today() - timedelta(days=7)).strftime('%Y%m%d')


datetime转换为timestamp
$ from datetime import datetime
$ dt = datetime(2017, 3, 29, 12, 20)  # 用指定日期创建datetime
$ dt.timestamp()  # 把datetime转换为timestamp

@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""
import datetime
import time

from pytz import timezone

zone = 'Asia/Shanghai'


class DateTimeHelper(object):
    """ Datetime helper

    """

    @classmethod
    def is_timestamp(cls, val):
        """ 判断是否是时间戳

        :param val:
        :return:
        """
        try:
            int(val)
            return True
        except ValueError:
            return False

    @classmethod
    def parse_formatted_datetime(cls, formatted_time: str, fmt: str):
        """ 解析已格式化的时间字符串，获得对应的时间戳

        :param formatted_time:
        :param fmt:
        :return:
        """
        return int(time.mktime(time.strptime(formatted_time, fmt)))

    @classmethod
    def format_datetime(cls, timestamp, fmt='%Y-%m-%d %H:%M:%S'):
        """ 获得给定时间戳对应的时间字符串

        :param timestamp: 时间戳
        :param fmt:
        :return:
        """
        if cls.is_timestamp(timestamp):
            return time.strftime(fmt, time.localtime(int(timestamp)))
        else:
            raise ValueError('%s is not timestamp.' % timestamp)

    @classmethod
    def get_china_timezone(cls):
        return timezone(zone)

    @classmethod
    def get_china_timezone_name(cls):
        return zone

    @classmethod
    def get_datetime_info(cls, timestamp):
        """ 获得时间的详细信息

        :param timestamp:
        :return:
        """
        datetime_obj = time.localtime(timestamp)
        return {
            'year': datetime_obj.tm_year,
            'month': datetime_obj.tm_mon,
            'day': datetime_obj.tm_mday,
            'hour': datetime_obj.tm_hour,
            'minute': datetime_obj.tm_min,
            'second': datetime_obj.tm_sec,
            'week_day': datetime_obj.tm_wday,  # 一周的第n天，0表示星期一，6表示星期日
            'year_day': datetime_obj.tm_yday  # 一年的第n天
        }

    @classmethod
    def get_differ_of_two_times(cls, start_timestamp, end_timestamp):
        """ 获得两个时间戳相差（天，小时，分钟，秒）
        :param start_timestamp:
        :param end_timestamp:
        :return:
        """
        if start_timestamp > end_timestamp:
            raise Exception('end_timestamp should greater than start_timestamp')

        start_time = cls.format_datetime(start_timestamp, '%Y-%m-%d-%H-%M-%S')
        end_time = cls.format_datetime(end_timestamp, '%Y-%m-%d-%H-%M-%S')

        diff_year = int(end_time.split('-')[0]) - int(start_time.split('-')[0])
        diff_month = diff_year * 12 + (int(end_time.split('-')[0]) - int(start_time.split('-')[0]))

        diff_minute = int((end_timestamp - start_timestamp) / 60)
        diff_hour = int((end_timestamp - start_timestamp) / 3600)
        diff_day = int((end_timestamp - start_timestamp) / (3600 * 24))

        return {
            'year': diff_year,
            'month': diff_month,
            'day': diff_day,
            'hour': diff_hour,
            'minute': diff_minute,
            'second': int(end_timestamp - start_timestamp)
        }

    @classmethod
    def get_previous_timestamp(cls, timestamp: int, day=None, hour=None):
        """ 获得timestamp的day/hour之前的时间戳

        :param timestamp:
        :param day:
        :param hour:
        :return:
        """
        if not cls.is_timestamp(timestamp):
            raise Exception('timestamp should be int type')

        if day is not None and hour is not None:
            return timestamp - day * 24 * 3600 - hour * 3600
        elif day is not None:
            return timestamp - day * 24 * 3600
        elif hour is not None:
            return timestamp - hour * 3600
        else:
            return timestamp

    @classmethod
    def get_previous_datestamp(cls, timestamp: int, day=None):
        """
        当day为正数时，获得n天前的日期戳；
        当day为空或0时，获得当天的日期戳；
        当day为负数时，获取n天之后的日期戳；

        :param timestamp:
        :param day:
        :return:
        """
        day = day or 0
        if cls.is_timestamp(timestamp):
            t = cls.format_datetime((timestamp - day * 24 * 3600), '%Y-%m-%d %H:%M:%S')[0:10]
            return cls.parse_formatted_datetime(t, '%Y-%m-%d')
        else:
            raise Exception('timestamp should be int type')
