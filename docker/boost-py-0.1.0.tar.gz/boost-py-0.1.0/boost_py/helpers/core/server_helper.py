#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

import socket


class ServerHelper(object):

    @classmethod
    def get_address_list(cls):
        """ 获得address list

        :return:
        """
        (name, alias_list, address_list) = socket.gethostbyname_ex(socket.gethostname())
        return address_list

    @classmethod
    def get_local_ip(cls):
        """ 或得内网ip

        :return:
        """
        return socket.gethostbyname(socket.gethostname())
