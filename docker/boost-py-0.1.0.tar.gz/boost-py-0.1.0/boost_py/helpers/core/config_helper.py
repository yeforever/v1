#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

from configparser import ConfigParser


class ConfigHelper(object):

    def __init__(self):
        pass

    def generate_config_file(self):
        config = ConfigParser()
        config["139.129.237.228"] = {"conf": "/etc/supervisor", "log-dir": "/alidata1/logs/supervisor"}
        with open('../temp/generate_config_file.conf', 'w') as config_file:
            config.write(config_file)

config_helper = ConfigHelper()

if __name__ == "__main__":
    config_helper.generate_config_file()


