#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

import csv
import sys
import os
import shutil


class FileHelper(object):

    @classmethod
    def exist(cls, path):
        """ 判断path是否存在

        :param path:
        :return:
        """
        if os.path.exists(path):
            return True
        else:
            return False

    @classmethod
    def read_from_csv(cls, file_path: str, newline: str="", encoding: str="utf-8"):
        """ 读取csv文件

        :param file_path: 文件路径
        :param newline: 默认为""，通用换行符模式（\n，\r或\r\n都可以作为换行标识），但不作转换为\n，保持原样全输入。如果设置为None，则统一转换为\n。
        :param encoding:
        :return:
        """
        if not os.path.exists(file_path):
            # TODO
            pass
        content = []
        with open(file_path, newline=newline, encoding=encoding) as f:
            reader = csv.reader(f)
            try:
                for row in reader:
                    content.append(row)
                return content
            except csv.Error as e:
                # TODO
                sys.exit("file {}, line {}: {}". format(file_path, reader.line_num, e))

    @classmethod
    def write_to_csv(cls,
                     csv_file_path: str,
                     input_data=[],
                     data_element_type: str='dict',
                     mode: str='w',
                     newline: str='',
                     encoding: str='utf-8'):
        """ 将data中数据写入到csv文件

        :param csv_file_path:
        :param input_data:
        :param data_element_type:
        :param mode:
        :param newline:
        :param encoding:
        :return:
        """
        with open(csv_file_path, mode, newline=newline, encoding=encoding) as f:
            if data_element_type == 'dict':
                writer = csv.DictWriter(f, fieldnames=input_data[0].keys(), delimiter=',', quotechar='"', quoting=csv.QUOTE_NONNUMERIC)
                writer.writeheader()
                for row in input_data:
                    writer.writerow(row)
            elif data_element_type == 'str':
                writer = csv.writer(f, delimiter=',', quotechar='"', quoting=csv.QUOTE_NONNUMERIC)
                for row in input_data:
                    writer.writerow(row)

    @classmethod
    def create(cls, path):
        """
        新建文件
        :param path:
        :return:
        """
        open(path, 'w')

    @classmethod
    def copy(cls, src, dst, override: bool = True):
        """ Copy data and all stat info ("cp -p src dst")

        :param src:
        :param dst:
        :param override:
        :return:
        """
        if override:
            cls.remove(dst)
        return shutil.copy2(src, dst)

    @classmethod
    def move(cls, src, dst):
        """ Move src file or directory to dest directory

        :param src:
        :param dst:
        :return:
        """
        if os.path.exists(src):
            if os.path.isfile(src):
                # src is file
                pass
            else:
                # src is directory
                pass
        else:
            pass
        shutil.move(src, dst)

    @classmethod
    def remove(cls, file_path):
        """ Remove file or directory

        :param file_path:
        :return:
        """
        if os.path.exists(file_path):
            if os.path.isfile(file_path):
                os.remove(file_path)
            if os.path.isdir(file_path):
                os.rmdir(file_path)

    @classmethod
    def makedir(cls, path, override: bool = True):
        """ 新建目录

        :param path: 新目录路径
        :param override: 是否覆盖，默认true
        :return:
        """
        if os.path.exists(path):
            if override:
                # 删除目录，并新建目录
                shutil.rmtree(path)
                os.makedirs(path)
        else:
            os.makedirs(path)

    @classmethod
    def replace_content(cls, file_path, old, new):
        """ 用新的内容替换文件中指定内容

        :param file_path: the file to update
        :param old: old str to replace
        :param new: new str
        :return:
        """
        file_data = ''
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                if old in line:
                    line = line.replace(old, new)
                file_data += line
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(file_data)

if __name__ == '__main__':
    FileHelper.create('/Users/guxu/yyy')
    print(FileHelper.exist('/Users/guxu/yyy'))

