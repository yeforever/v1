#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
微信APP爬虫底层系统任务管理Helper类

@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 17/4/2018 6:23 PM
"""

from requests_futures.sessions import FuturesSession
import requests

SERVICE_SUBMIT_TASK = 'submit_task'
SERVICE_VIEW_TASK = 'view_task'
SERVICE_CANCEL_TASK = 'cancel_task'


session = FuturesSession()


class WeixinAppSpiderSystemHelper(object):

    system_config = {}

    @classmethod
    def init(cls, system_config: dict):
        """ 初始化系统

        :param system_config:
        :return:
        """
        service_names = system_config.keys()
        if SERVICE_SUBMIT_TASK not in service_names or SERVICE_VIEW_TASK not in service_names or SERVICE_CANCEL_TASK not in service_names:
            raise Exception('submit_task OR view_task OR cancel_task not configured!')

        cls.system_config = system_config

    @classmethod
    def submit_task(cls, task_info: dict):
        """ 提交task

        :param task_info:
        :return:
        """
        if SERVICE_SUBMIT_TASK not in cls.system_config:
            raise Exception('should call init() first!')

        task_submit_service_url = cls.system_config[SERVICE_SUBMIT_TASK]
        session.post(task_submit_service_url, data=task_info)

    @classmethod
    def view_task(cls, global_task_uuid):
        """ 查看某个任务

        :param global_task_uuid:
        :return:
        """
        if SERVICE_VIEW_TASK not in cls.system_config:
            raise Exception('should call init() first!')

        resp = requests.get(cls.system_config[SERVICE_VIEW_TASK], {
            'global_task_uuid': global_task_uuid
        })

        return resp.json()['data']

    @classmethod
    def cancel_task(cls, global_task_uuid):
        """ 取消task

        :param global_task_uuid:
        :return:
        """
        if SERVICE_CANCEL_TASK not in cls.system_config:
            raise Exception('should call init() first!')

        task_cancel_url = cls.system_config[SERVICE_CANCEL_TASK]
        session.post(task_cancel_url, data={'global_task_uuid': global_task_uuid})
