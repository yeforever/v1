#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""

1. 下载sdk: dysms_python（https://help.aliyun.com/document_detail/55359.html?spm=a2c4g.11174283.6.594.47eb2c42pqGyUt）
2. 安装依赖
$ python3 setup.py install

@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 9/10/2018 2:29 PM
"""

from aliyunsdkdysmsapi.request.v20170525 import SendSmsRequest
import json

from aliyunsdkcore.client import AcsClient
from aliyunsdkcore.profile import region_provider


class AliSmsHelper(object):

    REGION = 'cn-hangzhou'
    PRODUCT_NAME = 'Dysmsapi'
    DOMAIN = 'dysmsapi.aliyuncs.com'

    access = {}
    ACCESS_KEY_ID = 'key_id'
    ACCESS_KEY_SECRET = 'key_secret'

    @classmethod
    def init(cls, access: dict):
        """ 初始化

        :param access:
        :return:
        """
        if cls.ACCESS_KEY_ID not in access or cls.ACCESS_KEY_SECRET not in access:
            raise Exception('{key_id} and {key_secret} should be configured.'.format(
                key_id=cls.ACCESS_KEY_ID,
                key_secret=cls.ACCESS_KEY_SECRET
            ))
        cls.access = access

    @classmethod
    def send_sms(cls, business_id, phone_numbers, sign_name, template_code, template_param=None):
        """

        :param business_id:
        :param phone_numbers:
        :param sign_name:
        :param template_code:
        :param template_param:
        :return:
        """
        if len(cls.access) == 0:
            raise Exception('Call init() first.')

        acs_client = AcsClient(cls.access[cls.ACCESS_KEY_ID], cls.access[cls.ACCESS_KEY_SECRET], cls.REGION)
        region_provider.add_endpoint(cls.PRODUCT_NAME, cls.REGION, cls.DOMAIN)

        sms_request = SendSmsRequest.SendSmsRequest()

        # 申请的短信模板编码，必填
        sms_request.set_TemplateCode(template_code)

        # 短信模板变量参数
        if template_param is not None:
            sms_request.set_TemplateParam(template_param)

        # 设置业务请求流水号，必填
        sms_request.set_OutId(business_id)

        # 短信签名
        sms_request.set_SignName(sign_name)

        # 短信发送的号码列表，必填
        sms_request.set_PhoneNumbers(phone_numbers)

        # 调用短信发送接口，返回json
        resp_json = acs_client.do_action_with_exception(sms_request)

        resp_arr = json.loads(resp_json)

        return {
            'err_code': 0 if 'Code' in resp_arr and resp_arr['Code'] == 'OK' else 1,
            'err_msg': resp_arr['Message']
        }
