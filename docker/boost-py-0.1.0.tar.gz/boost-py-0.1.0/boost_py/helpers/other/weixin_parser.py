#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
微信解析器

from boost_py.helpers.other.weixin_parser import WeixinParser

@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 16/4/2018 4:26 PM
"""

import time
import re
import json
from urllib import parse as url_parser
import requests
import html as html_parser
from collections import defaultdict

import pyquery

from ..core.datetime_helper import DateTimeHelper


class WeixinParser(object):

    @classmethod
    def parse_article_content(cls, article_content: str):
        """ 解析微信公众号文章内容页

        :param article_content:
        :return:
        {
            "weixin_id": "iyourdaily",
            "account_biz_code": "MzAwODI2OTA1MA==",
            "weixin_nickname": "",
            "account_desc": "",
            "article_title": "",
            "article_content": "",
            "is_orig": 0/1,
            "article_source_url": "",
            "article_short_desc": "",
            "article_pos": 4,
            "article_post_time": 1502063272,
            "article_formatted_post_time": "2017-08-07 07:47:52",
            "article_post_date": 1502035200,
            "article_formatted_post_date": "2017-08-07",
            "article_cover_img": "",
            "article_url": "https://mp.weixin.qq.com/s?__biz=MzAwODI2OTA1MA==&mid=2651997480&idx=4&sn=5b91fab817a9295bc2638ded5e07fcb6",
            "article_sn_code": "5b91fab817a9295bc2638ded5e07fcb6",
            "weixin_req_id": "1214phVdMscRcaQmwL9rBCZo"
        }
        """
        pq = pyquery.PyQuery(article_content)

        if pq.find("#js_profile_qrcode"):
            article = {
                "weixin_id": pq.find("#js_profile_qrcode "
                                     ".profile_inner .profile_meta").eq(0).find("span").text().strip(),
                "weixin_nickname": pq.find("#js_profile_qrcode .profile_inner strong").text().strip(),
                "account_desc": pq.find("#js_profile_qrcode .profile_inner "
                                        ".profile_meta").eq(1).find("span").text().strip(),
                "article_content": pq("#js_content").remove('script').text().replace(r"\r\n", ""),
                "is_orig": 1 if pq("#copyright_logo").length > 0 else 0,
                "article_source_url": pq("#js_sg_bar .meta_primary").attr('href') if pq(
                    "#js_sg_bar .meta_primary").length > 0 else '',
            }
            regexp_list = {
                "msg_cdn_url": {"regexp": "(?<=\").*(?=\")", "value": ""},  # 匹配文章封面图
                "var ct": {"regexp": "(?<=\")\d{10}(?=\")", "value": "-1"},  # 匹配文章发布时间
                "publish_time": {"regexp": "(?<=\")\d{4}-\d{2}-\d{2}(?=\")", "value": ""},  # 匹配文章发布日期
                "msg_desc": {"regexp": "(?<=\").*(?=\")", "value": ""},  # 匹配文章简介
                "msg_link": {"regexp": "(?<=\").*(?=\")", "value": ""},  # 匹配文章链接
                "msg_source_url": {"regexp": "(?<=').*(?=')", "value": ""},  # 获取原文链接
                "var biz": {"regexp": "(?<=\")\w{1}.+?(?=\")", "value": ""},
                "var idx": {"regexp": "(?<=\")\d{1}(?=\")", "value": "-1"},
                "var mid": {"regexp": "(?<=\")\d{10,}(?=\")", "value": ""},
                "var sn": {"regexp": "(?<=\")\w{1}.+?(?=\")", "value": ""},
                "var req_id": {"regexp": "(?<=')\w{1}.+?(?=')", "value": ""},
                "var msg_title": {"regexp": "(?<=\").*(?=\")", "value": ""}
            }
            count = 0
            for line in article_content.split("\n"):
                for item_key, regexp_item in regexp_list.items():
                    if item_key in line:
                        matched = re.search(regexp_item["regexp"], line)
                        if matched is not None:
                            count += 1
                            regexp_list[item_key]["value"] = matched.group(0)
                        break
                if count >= len(regexp_list):
                    break

            article["article_short_desc"] = regexp_list["msg_desc"]["value"]
            article["article_pos"] = int(regexp_list["var idx"]["value"])

            article["article_post_time"] = int(regexp_list["var ct"]["value"])
            article["article_formatted_post_time"] = time.strftime("%Y-%m-%d %H:%M:%S",
                                                                   time.localtime(article["article_post_time"]))
            article["article_post_date"] = DateTimeHelper.get_previous_datestamp(article["article_post_time"], 0)
            article["article_formatted_post_date"] = DateTimeHelper.format_datetime(article["article_post_date"],
                                                                                    '%Y-%m-%d')

            article["article_cover_img"] = regexp_list["msg_cdn_url"]["value"]
            article["article_source_url"] = regexp_list["msg_source_url"]["value"]
            article["article_url"] = "https://mp.weixin.qq.com/s?__biz={biz}&mid={mid}&idx={idx}&sn={sn}".format(
                biz=regexp_list["var biz"]["value"],
                mid=regexp_list["var mid"]["value"],
                idx=regexp_list["var idx"]["value"],
                sn=regexp_list["var sn"]["value"]
            )
            article["account_biz_code"] = regexp_list["var biz"]["value"]
            article["article_sn_code"] = regexp_list["var sn"]["value"]
            article["article_mid_code"] = regexp_list["var mid"]["value"]
            article["weixin_req_id"] = regexp_list["var req_id"]["value"]
            article["article_title"] = regexp_list["var msg_title"]["value"]
            return article

        else:
            # 该文章已被发布者删除
            return None

    @classmethod
    def parse_profile_page(cls, page_content: str):
        """ 解析微信app里的账号profile页（历史文章列表页）
        :return:
        """
        # TODO
        pass

    @classmethod
    def parse_article_url(cls, article_url: str):
        """ 解析微信文章url

        微信文章url包括以下三种类型：
        1) sogou
        https://mp.weixin.qq.com/s?timestamp=1498476633&src=3&ver=1&signature=n8LyRRNUP1BTTSXtCxJW7RPwSSrcOHhTukR-M1QoqyVPpK*zLgyETbeLq5EPeUPjDi8UHH1AJGO9ckunAufrXteJcVa0oxqRoJfBy0R0LYfCRcj30tFuphv3A6-8THoJ4C3iGJXdh3DCvcCUgoD87L-hGW-n3efx-MHR7bzUqaA=
        https://mp.weixin.qq.com/s?src=3&timestamp=1498476655&ver=1&signature=klbov99mFF011qucs7Ebl8pcecUBN2EegQLiomyetl3H*80IxbeRlhDNr9tRWWQV8VLqlMdLAHs9c1JEh5u3sed3vYHQ9PZxLrk1kiVmcXqA7YAVQrYj*pBjxTOTr4i55sNAJfhodGaTyGFj43fE9I9*rhOIce0yvREPkKbG1Uw=
        http://weixin.sogou.com/api/share?timestamp=1510197976&signature=qIbwY*nI6KU9tBso4VCd8lYSesxOYgLcHX5tlbqlMR8N6flDHs4LLcFgRw7FjTAObr-vOnuyE2KKKEQniK9VNCpk1HWVWsm*Iex7J*KRDS8MfneAXF89FXe1cWd*qjbudH8JolasY7lwItzYKufR*k*TvrJovBc*XTxZ9Bjs83ha*WRy80hODe07v9ESYcJP8r1jL7bYcj99nCYNyGZoNT5HCZoyfG8heSPoO7Of8bw=

        2) 微信app里的短链
        https://mp.weixin.qq.com/s/DQ9M_qBnlof-8hgk4DcWbw

        3) 微信文章链接
        https://mp.weixin.qq.com/s?__biz=MjM5NDI0NDI1NQ==&mid=2650183652&idx=1&sn=757c718b56c7320d5e7d79ee011e0ab7&scene=0#wechat_redirect

        :param article_url:
        :return:
        {
            "come_from": -1/1/2/3
            "account_biz_code": "",
            "article_sn_code": "",
            "article_mid_code": "",
            "article_idx": "",
            "origin_article_url": article_url
        }
        或者
        {}
        """
        url_info = {}  # 链接信息

        come_from = -1
        if 's?timestamp' in article_url:
            # 链接来自搜狗
            come_from = 1
        elif 's?src' in article_url:
            # 链接来自搜狗
            come_from = 1
        elif 'weixin.sogou.com' in article_url:
            # 链接来自搜狗
            come_from = 1
        elif 's?__biz' in article_url:
            # 微信链接
            come_from = 3
        elif 'mp.weixin.qq.com' in article_url:
            # 微信app短链
            come_from = 2

        url_info['come_from'] = come_from

        if come_from == 3:
            url_param_items = url_parser.parse_qs(url_parser.urlparse(article_url).query).items()
            article_url_params = {param_name: param_values[0] for param_name, param_values in url_param_items}
            url_info['account_biz_code'] = article_url_params['__biz']
            url_info['article_sn_code'] = article_url_params['sn']
            url_info['article_mid_code'] = article_url_params['mid']
            url_info['article_pos'] = article_url_params['idx']
            url_info['origin_article_url'] = article_url
            return url_info
        else:
            return url_info

    @classmethod
    def parse_weixin_app_home_url(cls, home_url):
        """ 解析账号home url

        :param home_url:
        :return:
        """
        home_url_info = {}
        url_param_items = url_parser.parse_qs(url_parser.urlparse(home_url).query).items()
        home_url_params = {param_name: param_values[0] for param_name, param_values in url_param_items}
        home_url_info["account_biz_code"] = home_url_params["__biz"]
        return home_url_info

    @classmethod
    def get_article_info(cls, article_url):
        """ 通过解析提交的文章链接，获取文章所有信息

        :param article_url:
        :return:
        """
        # 解析文章url，获取文章链接里的参数
        article_url = article_url.strip()
        url_info = cls.parse_article_url(article_url)

        # 通过文章url，get请求，获取页面html内容并解析，获取文章参数信息
        # 有些情况下，get返回的结果无法解析获取biz code，则重试
        account_biz_code = ''
        url_check_retry_limit_time = 3
        url_check_retry_time = 0
        while account_biz_code == '' and url_check_retry_time < url_check_retry_limit_time:
            resp = requests.get(article_url)
            article_info = cls.parse_article_content(resp.text)  # 解析文章内容
            if article_info is None:
                return None
            account_biz_code = article_info['account_biz_code']
            if url_check_retry_time > 1:
                time.sleep(2)
            url_check_retry_time += 1
        if account_biz_code == '':
            return None

        if url_info['come_from'] == 2 or url_info['come_from'] == 3:
            # 微信url和短链可以获取到biz code和sn code
            article_url = 'https://mp.weixin.qq.com/s?__biz={biz}&mid={mid}&idx={idx}&sn={sn}'.format(
                    biz=article_info['account_biz_code'],
                    mid=article_info['article_mid_code'],
                    idx=article_info['article_pos'],
                    sn=article_info['article_sn_code']
            )

        article_info['article_url'] = article_url

        return article_info

    @classmethod
    def get_read_like_info(cls, article_url: str, article_ext_content: str):
        """
        解析文章阅读点赞
        :param article_url:
        :param article_ext_content:
        :return:
        {
            "account_biz_code": "",
            "article_sn_code": "",
            "article_mid_code": "",
            "article_idx": "",
            "article_url": "",
            "read_num": "",
            "like_num": ""
        }
        """
        article_read_like_info = {}

        article_url_info = cls.parse_article_url(article_url)
        if article_url_info['come_from'] != 3:
            return False

        article_read_like_info['account_biz_code'] = article_url_info['account_biz_code']
        article_read_like_info['article_sn_code'] = article_url_info['article_sn_code']
        article_read_like_info['article_mid_code'] = article_url_info['article_mid_code']
        article_read_like_info['article_pos'] = article_url_info['article_pos']

        article_read_like_info[
            'article_url'] = "https://mp.weixin.qq.com/s?__biz={biz}&mid={mid}&idx={idx}&sn={sn}".format(
                biz=article_read_like_info['account_biz_code'],
                mid=article_read_like_info['article_mid_code'],
                idx=article_read_like_info['article_pos'],
                sn=article_read_like_info['article_sn_code']
        )

        article_ext_info = json.loads(article_ext_content)
        article_read_like_info['read_num'] = article_ext_info['appmsgstat']['read_num']
        article_read_like_info['like_num'] = article_ext_info['appmsgstat']['like_num']

        return article_read_like_info

    @classmethod
    def parse_app_home_page_without_follow(cls, home_html_content: str):
        """ 解析微信里账号home页面

        :param home_html_content:
        :return:
        {
            "weixin_id": "xxx",
            "weixin_nickname": "xxx",
            "account_desc": "xxx",
            "article_groups": [
                1494496442: ["url_1", "url_2", "url_3"],
                1495101720: ["url_1", "url_2", "url_3"]
            ],
            "articles": ["url_1", "url_2", "url_3"],
            "latest_articles": ["url_1", "url_2", "url_3"],
            "latest_post_time": 1494496442
        }
        """
        pq = pyquery.PyQuery(home_html_content)

        err_msg = pq.find(".weui-msg__desc").text().strip()
        if "公众号帐号迁移" in err_msg:
            return {
                "err": 1,
                "err_msg": err_msg
            }

        account_info = {
            "weixin_id": "",
            "weixin_nickname": pq.find("#nickname").text().strip(),
            "account_desc": pq.find("div.profile_info p.profile_desc").text().strip(),
            "article_groups": {},
            "articles": [],
            "latest_articles": [],
            "latest_post_time": -1
        }

        latest_post_time = -1
        for line in home_html_content.split("\n"):
            if line.find("var msgList =") > 0:
                line = html_parser.unescape(line.strip()).replace("\\", "")
                equal_pos = line.find("=")
                latest_ten_posts = json.loads(line[equal_pos + 1: -1][2:-1])
                urls = defaultdict(list)
                for post in latest_ten_posts["list"]:
                    try:
                        # 图文的类型是49
                        if post["comm_msg_info"]["type"] == 49:
                            urls[post["comm_msg_info"]["datetime"]].append(post["app_msg_ext_info"]["content_url"])
                            urls[post["comm_msg_info"]["datetime"]].extend(
                                    [item["content_url"] for item in
                                     post["app_msg_ext_info"]["multi_app_msg_item_list"]])
                            urls[post["comm_msg_info"]["datetime"]] = list(map(lambda url: html_parser.unescape(url),
                                                                               urls[post["comm_msg_info"]["datetime"]]))

                            for article_url in urls[post["comm_msg_info"]["datetime"]]:
                                account_info["articles"].append(article_url)

                            # 获取最近群发的文章发布时间
                            article_post_time = int(post["comm_msg_info"]["datetime"])
                            if article_post_time > latest_post_time:
                                latest_post_time = article_post_time
                    except(ValueError, Exception) as e:
                        return {
                            "err": 1,
                            "err_msg": e
                        }

                account_info["article_groups"] = dict(urls)
        account_info["latest_articles"] = account_info["article_groups"][latest_post_time]
        account_info["latest_post_time"] = latest_post_time
        return account_info

    @classmethod
    def get_app_home_url(cls, weixin_id: str):
        """ 根据weixin id获得在微信里的公众号详情页（文章列表页）
        :param weixin_id:
        :return: https://mp.weixin.qq.com/mp/profile_ext?action=home&__biz=MzI4NTA1MDEwNg==
        """
        # TODO
        account_biz_code = cls.get_account_biz_code(weixin_id)
        home_url = ""
        return home_url

    # @classmethod
    # def get_account_biz_code(cls, weixin_id: str):
    #     """ 根据weixin id获得account biz code
    #     :param weixin_id:
    #     :return:
    #     """
    #     # TODO
    #     redis_client = StorageConnectionFactory.get_redis_client("prod", "dts")
    #     account_biz_code = redis_client.hget("WEIXIN_BIZ_HASH_KEY", weixin_id)
    #     if account_biz_code is None:
    #         # TODO 抛出错误
    #         return ""
    #     if account_biz_code is not None and isinstance(account_biz_code, bytes):
    #         account_biz_code = account_biz_code.decode()
    #     return account_biz_code

    @classmethod
    def parse_weixin_article_comment(cls, comment: str) -> list:
        """ 解析文章评论

        :param comment:
        :return:
        """
        return [
            {
                "nickname": comment["nick_name"],
                "logo_url": comment["logo_url"],
                "like_num": comment["like_num"],
                "content": comment["content"],
                "create_time": comment["create_time"],

            } for comment in json.loads(comment)["elected_comment"]
            ]

    @classmethod
    def get_visitor_nickname(cls, content: str):
        """ 解析文章访问者昵称

        :param content:
        :return:
        """
        try:
            content_dict = json.loads(content)
            nickname = content_dict['nick_name']
        except (json.JSONDecodeError, Exception):
            nickname = ''
        return nickname

    @classmethod
    def url_come_from_sogou(cls, article_url):
        """ 链接是否来自搜狗

        :param article_url:
        :return:
        """
        if 'weixin.sogou.com' in article_url or 's?src' in article_url or "s?timestamp" in article_url:
            return True
        else:
            return False

    @classmethod
    def parse_sogou_weixin_article_search_item(cls, item_content):
        """ 解析来自搜狗微信文章搜索中搜索结果

        :param item_content:
        :return:
        """
        item = {
            'title': {'regex': '<title><\!\[CDATA\[(.*)\]\]></title>', 'value': ''},    # 标题
            'imglink': {'regex': '<imglink><\!\[CDATA\[(.*)\]\]></imglink>', 'value': ''},    # 文章封面
            'headimage': {'regex': '<headimage><\!\[CDATA\[(.*)\]\]></headimage>', 'value': ''},    # 公众号头像
            'sourcename': {'regex': '<sourcename><\!\[CDATA\[(.*)\]\]></sourcename>', 'value': ''},    # 公众号名称
            'content168': {'regex': '<content168><\!\[CDATA\[(.*)\]\]></content168>', 'value': ''},    # 文章简介
            'username': {'regex': '<username><\!\[CDATA\[(.*)\]\]></username>', 'value': ''},    # 公众号id
            'readnum': {'regex': '<readnum>(\w+)</readnum>', 'value': ''},    # 阅读数
            'forwardnum': {'regex': '<forwardnum>(\w+)</forwardnum>', 'value': ''},    # 点赞数
            'openid': {'regex': '<openid><\!\[CDATA\[(.*)\]\]></openid>', 'value': ''},    # 微信的openid
            # 'shareUrl': {'regex': '<shareUrl><\!\[CDATA\[(.*)\]\]></shareUrl>', 'value': ''},    # 文章链接
            'shareUrl': {'regex': '<encArticleUrl><\!\[CDATA\[(.*)\]\]></encArticleUrl>', 'value': ''},    # 文章链接
            'lastModified': {'regex': '<lastModified>(\w+)</lastModified>', 'value': ''},    # 新建日期 1553567123
            'date': {'regex': '<date><\!\[CDATA\[(.*)\]\]></date>', 'value': ''},    # 新建日期 如2018-6-4
            'source_url': {'regex': '<site><\!\[CDATA\[(.*)\]\]></site>', 'value': ''}
        }

        for k, v in item.items():
            try:
                v["value"] = re.search(v["regex"], item_content).group(1)
            except AttributeError:
                pass

        formatted_post_date = DateTimeHelper.format_datetime(item['lastModified']['value'], '%Y-%m-%d')
        return {
                'openid': item['openid']['value'],
                'weixin_id': item['username']['value'],
                'article_cover_img': item['imglink']['value'],
                'weixin_nickname': item['sourcename']['value'],
                'account_avatar_img': item['headimage']['value'],
                'profile_url': '',
                'account_biz_code': '',
                'article_sn_code': '',
                'article_mid_code': '',
                'title':  item['title']['value'],
                'has_video': 0,
                'article_url': item['shareUrl']['value'],
                'article_short_desc': item['content168']['value'],
                'article_source_url': item['source_url']['value'],
                'is_orig': '',
                'article_pos': '',
                'article_post_time': int(item['lastModified']['value']),
                'article_post_date': DateTimeHelper.parse_formatted_datetime(item['date']['value'], '%Y-%m-%d'),
                'article_formatted_post_time': DateTimeHelper.format_datetime(item['lastModified']['value']),
                'article_formatted_post_date': formatted_post_date,
                'read_num': int(item['readnum']['value']),
                'like_num': int(item['forwardnum']['value'])
            }
