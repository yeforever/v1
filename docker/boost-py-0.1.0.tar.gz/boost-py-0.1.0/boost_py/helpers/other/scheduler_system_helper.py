#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 17/4/2018 6:23 PM
"""

import requests


class SchedulerSystemHelper(object):

    system_config = {}

    JOB_TYPE_INTERVAL = 'interval'
    JOB_TYPE_DATE = 'date'
    JOB_TYPE_CRON = 'cron'

    API_SUBMIT_JOB = 'submit_job'
    API_VIEW_JOB = 'view_job'
    API_LIST_JOB = 'list_job'
    API_CANCEL_JOB = 'cancel_job'

    @classmethod
    def init(cls, system_config: dict):
        """ 初始化系统

        :param system_config:
        :return:
        """
        api_names = system_config.keys()
        if cls.API_SUBMIT_JOB not in api_names or cls.API_VIEW_JOB not in api_names or cls.API_LIST_JOB not in api_names or cls.API_CANCEL_JOB not in api_names:
            raise Exception('submit_job OR view_job OR list_job OR cancel_job not configured!')

        cls.system_config = system_config

    @classmethod
    def submit_job(cls, target_service: dict, scheduler_settings: dict):
        """ 提交job

        :param target_service:
        :param scheduler_settings:
        :return:
        """
        if cls.API_SUBMIT_JOB not in cls.system_config:
            raise Exception('should call init() first!')

        if 'schedule_type' in scheduler_settings \
                and scheduler_settings['schedule_type'] in [cls.JOB_TYPE_INTERVAL, cls.JOB_TYPE_DATE, cls.JOB_TYPE_CRON]:

            if scheduler_settings['schedule_type'] == 'interval':

                if 'start_time' not in scheduler_settings \
                        or 'end_time' not in scheduler_settings \
                        or 'interval_time' not in scheduler_settings:

                    raise Exception('invalid config for interval job')

            elif scheduler_settings['schedule_type'] == 'cron':

                if 'start_time' not in scheduler_settings \
                        or 'end_time' not in scheduler_settings \
                        or 'cron_expression' not in scheduler_settings:
                    raise Exception('invalid config for cron job')

            elif scheduler_settings['schedule_type'] == 'date':

                if 'run_date' not in scheduler_settings:
                    raise Exception('invalid config for date job')

        else:
            raise Exception('boost scheduler system only support interval | cron | date job')

        scheduler_job_submit_url = cls.system_config[cls.API_SUBMIT_JOB]
        r = requests.post(scheduler_job_submit_url,
                          json=target_service,
                          params=scheduler_settings)

        try:
            rtn = r.json()
        except Exception:
            raise Exception('response json parse error. resp text: {resp_text}, resp code: {resp_code}'.format(
                resp_text=r.text,
                resp_code=r.status_code
            ))

        if 'err_code' in rtn and rtn['err_code'] == 1:
            raise Exception('job submit error. err msg: {err_msg}'.format(
                err_msg=rtn['err_msg']
            ))

        if 'data' in rtn and 'job_uuid' in rtn['data']:
            return rtn['data']['job_uuid']
        else:
            raise Exception('no job uuid')

        return None

    @classmethod
    def view_job(cls):
        pass

    @classmethod
    def cancel_job(cls, job_uuid):
        """ 取消某个job

        :param job_uuid:
        :return:
        """
        if cls.API_CANCEL_JOB not in cls.system_config:
            raise Exception('should call init() first!')

        scheduler_job_cancel_url = cls.system_config[cls.API_CANCEL_JOB]
        r = requests.post(scheduler_job_cancel_url,
                          data={'job_uuid': job_uuid})

        try:
            rtn = r.json()
        except ValueError:
            raise Exception('response json parse error. resp text: {resp_text}, resp code: {resp_code}'.format(
                resp_text=r.text,
                resp_code=r.status_code
            ))

        if 'err_code' in rtn and rtn['err_code'] == 1:
            raise Exception('job cancel error. err msg: %s' % rtn['err_msg'])

        return True

    @classmethod
    def cancel_jobs(cls, job_id_list):
        """ 取消指定的若干个job

        :param job_id_list:
        :return:
        """
        pass

    @classmethod
    def cancel_all_jobs(cls):
        """ 取消所有的job

        :return:
        """
        pass

    @classmethod
    def parse_cron_expression(cls, cron_expression):
        """ 解析cron expression

        :param cron_expression:
        :return:
        """
        # TODO
        return {
            'year': '*',
            'month': '*',
            'day': '*',
            'week': '*',
            'day_of_week': '*',
            'hour': '*',
            'minute': '*',
            'second': '*'
        }