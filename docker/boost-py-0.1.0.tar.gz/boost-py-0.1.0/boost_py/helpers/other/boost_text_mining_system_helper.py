#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 16/11/2018 10:37 AM
"""

import requests


class BoostTextMiningSystemHelper(object):

    API_SUBMIT_KEYWORD_CLOUD_TASK = 'submit_keyword_cloud_task'
    API_VIEW_KEYWORD_CLOUD_TASK = 'view_keyword_cloud_task'

    @classmethod
    def init(cls, system_config: dict):
        """ 初始化系统

        :param system_config:
        :return:
        """
        api_names = system_config.keys()
        if cls.API_SUBMIT_KEYWORD_CLOUD_TASK not in api_names or cls.API_VIEW_KEYWORD_CLOUD_TASK not in api_names:
            raise Exception('submit_keyword_cloud_task OR view_keyword_cloud_task not configured!')

        cls.system_config = system_config

    @classmethod
    def submit_keyword_cloud_task(cls, text_content, word_limit=20, running_mode='sync'):
        try:
            r = requests.post(cls.system_config[cls.API_SUBMIT_KEYWORD_CLOUD_TASK],
                              json={
                                  'text_content': text_content,
                                  'word_limit': word_limit,
                                  'running_mode': running_mode
                              },
                              timeout=10)
        except requests.exceptions.Timeout:
            return {
                'err_code': 1,
                'err_msg': 'request timeout.'
            }

        if r.status_code == requests.codes.ok:
            try:
                word_cloud = r.json()['data']['word_cloud']
                return {
                    'err_code': 0,
                    'err_msg': '',
                    'data': {
                        'word_cloud': word_cloud
                    }
                }
            except ValueError:
                return {
                    'err_code': 1,
                    'err_msg': 'response body does not contain valid json.'
                }
            except KeyError:
                return {
                    'err_code': 1,
                    'err_msg': 'response body does not contain valid word_cloud data.'
                }
        else:
            return {
                'err_code': 1,
                'err_msg': 'request fail, response status code: %s.' % r.status_code
            }

