boost-py
===========
Boost Python Project For Quick Start

包括：
1. helper工具类或方法
2. sample示例

cd xxx/boost-py
 # python3 setup.py sdist
 # pip3 uninstall boost-py
 # pip3 install dist/boost-py-0.1.0.tar.gz