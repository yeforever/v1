#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 2/5/2018 11:18 AM
"""

import unittest
import time

from boost_py.helpers.core.datetime_helper import DateTimeHelper


class DatetimeHelperTests(unittest.TestCase):

    def test_is_timestamp(self):
        print('%d is timestamp: %s' % (1524499200, DateTimeHelper.is_timestamp(1524499200)))

    def test_parse_formatted_datetime(self):
        timestamp = DateTimeHelper.parse_formatted_datetime(formatted_time='2018-07-30 23:17:11',
                                                            fmt='%Y-%m-%d %H:%M:%S')
        print(timestamp)

        print('=====')
        formatted_time = DateTimeHelper.format_datetime(timestamp=timestamp,
                                                        fmt='%Y-%m-%d %H:%M:%S')
        print(formatted_time)
        formatted_date = DateTimeHelper.format_datetime(timestamp=timestamp,
                                                        fmt='%Y-%m-%d')
        print(formatted_date)

    def test_get_CST_timestamp(self):
        #print(DateTimeHelper.parse_formatted_datetime('Mon Jan 24 23:53:07 +0800 2011', '%a %b %d %H:%M:%S CST %Y'))
        resTime = time.strftime('%Y%m%d %H%M%S', time.strptime('Wed Jun 27 09:10:12 +0800 2018', '%a %b %d %H:%M:%S +0800 %Y'))
        print((DateTimeHelper.parse_formatted_datetime(resTime, '%Y%m%d %H%M%S')))

    def test_get_datetime_info(self):
        from pprint import pprint
        pprint(DateTimeHelper.get_datetime_info(int(time.time())))

    def test_get_differ_of_two_times(self):
        print(DateTimeHelper.get_differ_of_two_times(1531411200, time.time()))

    def test_get_previous_timestamp(self):
        print(DateTimeHelper.get_previous_timestamp(1533517200, day=-1))
        print(DateTimeHelper.format_datetime(DateTimeHelper.get_previous_timestamp(1533517200, day=1),'%Y-%m-%d %H:%M:%S'))
        print(DateTimeHelper.format_datetime(DateTimeHelper.get_previous_timestamp(1533517200),'%Y-%m-%d %H:%M:%S'))

    def test_get_datestamp(self):
        """ 获取给定某个时间的那一天的时间戳和格式化时间。
        比如给定时间：2018-07-30 23:17:11，
        得到当天日期的时间戳：1532880000，当天日期：2018-07-30 00:00:00

        :return:
        """
        timestamp = DateTimeHelper.parse_formatted_datetime(formatted_time='2018-07-30 23:17:11',
                                                            fmt='%Y-%m-%d %H:%M:%S')
        datestamp = DateTimeHelper.get_previous_datestamp(timestamp)
        print(datestamp)  # 获得当天日期的时间戳：1532880000

        format_datetime = DateTimeHelper.format_datetime(datestamp, '%Y-%m-%d %H:%M:%S')  # 获得当天日期 2018-07-30 00:00:00
        print(format_datetime)

if __name__ == '__main__':
    unittest.main()
