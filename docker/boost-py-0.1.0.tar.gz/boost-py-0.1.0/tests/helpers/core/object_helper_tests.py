#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 23/7/2018 4:30 PM
"""

import unittest
from pprint import pprint

from boost_py.helpers.core.object_helper import ObjectHelper


class ObjectHelperTests(unittest.TestCase):

    def test_to_str(self):
        pass


if __name__ == '__main__':
    unittest.main()