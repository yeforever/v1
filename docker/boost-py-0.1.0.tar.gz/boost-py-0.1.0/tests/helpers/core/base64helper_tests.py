#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

import base64
import unittest

from boost_py.helpers.base64_helper import Base64Helper


class Base64Tests(unittest.TestCase):
    """

    """

    # def test_safe_b64decode(self):
    #     self.assertEqual(Base64Helper.safe_b64decode(b'abcd\x00string'), b'YWJjZA')

    def test_b64encode(self):
        self.assertEqual(base64.b64encode(b'i\xb7\x1d\xfb\xef\xff'), b'abcd++//')

    def test_urlsafe_b64encode(self):
        self.assertEqual(base64.urlsafe_b64encode(b'i\xb7\x1d\xfb\xef\xff'), b'abcd--__')

    def test_b64decode(self):
        self.assertEqual(base64.b64decode('abcd++//'), b'i\xb7\x1d\xfb\xef\xff')

    def test_urlsafe_b64decode(self):
        self.assertEqual(base64.urlsafe_b64decode('abcd--__'), b'i\xb7\x1d\xfb\xef\xff')

    def test_safe_b64decode(self):
        self.assertEqual(Base64Helper.safe_b64decode('YWJjZA'), b'abcd')


if __name__ == '__main__':
    unittest.main()