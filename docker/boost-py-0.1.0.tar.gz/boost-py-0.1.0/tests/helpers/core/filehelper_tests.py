#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 7/8/17 9:24 PM
"""

import unittest

from boost_py.helpers.core.file_helper import FileHelper


class FileHelperTests(unittest.TestCase):

    def test_write_to_csv(self):
        data1 = [
            {
                'name': 'aaa',
                'age': 11
            },
            {
                'name': 'bbb',
                'age': 22
            },
            {
                'name': 'ccc',
                'age': 33
            }
        ]

        data2 = ['abc', 'efg', 'hij']

        FileHelper.write_to_csv(
                csv_file_path='/Users/guxu/workspace/boost-platform/boost-py/data/test_write_to_csv.csv',
                input_data=data1,
                data_element_type='dict'
        )

    def test_make_dir(self):
        FileHelper.makedir(path='/Users/guxu/Documents/workspace/python/boost-py/tmp/file/aa/bb')


if __name__ == '__main__':
    unittest.main()
