#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 4/7/2018 10:17 AM
"""

import unittest
from pprint import pprint

from boost_py.helpers.core.http_helper import HttpHelper


class HttpHelperTests(unittest.TestCase):

    def test_parse_url_qs(self):
        url = 'http://weixin.sogou.com/weixinwap?page=100&total_pages=100&_rtype=json&query=%E5%90%AF%E8%B5%8B%E5%A5%B6%E7%B2%89&type=2&ie=utf8&_sug_=n&_sug_type_=-1&s_from=input&task_uuid=cfefb2ef-33ce-44ab-9826-5d555c170c48'
        qs = HttpHelper.parse_url_qs(url)
        pprint(qs)


if __name__ == '__main__':
    unittest.main()
