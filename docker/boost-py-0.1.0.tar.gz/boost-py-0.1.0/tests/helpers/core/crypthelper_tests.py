#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 14/4/2018 10:45 PM
"""

import unittest

from boost_py.helpers.crypt_helper import CryptHelper


class CryptHelperTests(unittest.TestCase):

    def test_encrypt_password(self):
        hashed = CryptHelper.encrypt_password('111111')
        self.assertEqual(CryptHelper.validate_password(hashed, '1111112'), True)


if __name__ == '__main__':
    unittest.main()