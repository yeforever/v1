#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 30/5/2018 4:12 PM
"""

import unittest

from boost_py.helpers.other.weixin_parser import WeixinParser
import requests


class WeixinParserTests(unittest.TestCase):

    def test_view_article(self):
        article_url = 'http://mp.weixin.qq.com/s?src=11&timestamp=1534907762&ver=1075&signature=vOTciB2jVWaxpxv4QcWzGNZMp6yMaa*x1BWiSI54e42Enz9xVuZPSSRImSkS4b6ZN9b9Nd5Z1tB2KHHlinflExxK72upeQc4TlvMl0arTFDRKRQEAnnPFTn5SnkRXJm8&new=1&task_uuid=69b3f8c9-227f-4f6e-83ba-a80068da5869'
        resp = requests.get(article_url)
        resp.encoding = 'utf-8'
        print(resp.text)

    def test_get_article_info_none(self):
        """
        测试页面文章被删除后,是否返回None
        :return:
        """
        article_url = 'https://mp.weixin.qq.com/s?__biz=MjM5NTAyODc2MA==&mid=2654457756&idx=3&sn=f6139f5a49c0b8297995f6f3f1ca187d&chksm=bd3da5eb8a4a2cfdfa6e91c56f3c5ba6a3ee3517eb8b68e26b4d426c7445b00a4277d71eccf8#rd'
        info = WeixinParser.get_article_info(article_url)
        print(info)

    def test_get_article_info(self):
        """ 文章信息

        :return:
        """
        article_url = 'https://mp.weixin.qq.com/s/mBGTdHPFu9zXKDoIPiUhEg'
        article_info = WeixinParser.get_article_info(article_url)
        from pprint import pprint
        pprint(article_info)

    def test_parse_sogou_weixin_article_search_item(self):
        WeixinParser.parse_sogou_weixin_article_search_item('')


if __name__ == '__main__':
    unittest.main()
