#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 30/7/2018 4:44 PM
"""

import unittest
import json

from boost_py.helpers.other.scheduler_system_helper import SchedulerSystemHelper

BOOST_SCHEDULER_SYSTEM = {
    'submit_job': 'http://boost-scheduler-system.womdata.com/job/submit',
    'view_job': 'http://boost-scheduler-system.womdata.com/job/view',
    'list_job': 'http://boost-scheduler-system.womdata.com/job/list',
    'cancel_job': 'http://boost-scheduler-system.womdata.com/job/cancel',
    'cancel_all_jobs': 'http://boost-scheduler-system.womdata.com/job/cancel-all'
}

# init scheduler system
SchedulerSystemHelper.init(system_config=BOOST_SCHEDULER_SYSTEM)


class SchedulerSystemHelperTests(unittest.TestCase):

    def test_submit_interval_job(self):
        """ 测试提交interval型的job

        :return:
        """
        scheduler_job_id = SchedulerSystemHelper.submit_job(
            target_service={
                'job_name': '微信文章监控',
                'job_desc': '微信文章监控',
                'target_url': 'target app url',
                'request_params': json.dumps({
                    'some param': 'param value'
                }),
                'request_method': 'POST'
            },
            scheduler_settings={
                'schedule_type': 'interval',
                'start_time': 1524499200,  # 开始时间：e.g. 2018-07-30 16:07:50
                'end_time': 1564499200,  # 结束时间：e.g. 2018-10-08 12:10:23
                'interval_time': 10  # 间隔时间：10秒
            }
        )

        print(scheduler_job_id)

    def test_submit_cron_job(self):
        """ 测试提交cron型的job

        :return:
        """
        scheduler_job_id = SchedulerSystemHelper.submit_job(
            target_service={
                'job_name': '微信榜单计算',
                'job_desc': '微信榜单计算',
                'target_url': 'target app url',
                'request_params': json.dumps({
                    'some param': 'param value'
                }),
                'request_method': 'GET'
            },
            scheduler_settings={
                'schedule_type': 'cron',
                'start_time': 1524499200,  # 开始时间，e.g. 2018-07-30 16:07:50
                'end_time': 1564499200,  # 结束时间，e.g. 2018-10-08 12:10:23
                'cron_expression': '28 16 * * *'  # 每天16点28分执行
            }
        )

        print(scheduler_job_id)

if __name__ == '__main__':
    unittest.main()

