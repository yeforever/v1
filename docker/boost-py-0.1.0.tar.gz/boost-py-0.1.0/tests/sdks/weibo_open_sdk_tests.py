#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@version: 1.0
@author: guu
@contact: yeexiao@yeah.net
@time: 30/5/2018 4:12 PM
"""
import json
import unittest
from pprint import pprint

from boost_py.sdks.weibo_open_sdk import WeiboOpenSdk


WEIBO_CONFIG = {"access_token": "2.00qVPMuGDdZzSD4c489518f0NwDN9C",
                "remind_in": "157679999",
                "expires_in": 157679999,
                "uid": "6327191378",
                "isRealName": "true"}
ACCESS_TOKEN = WEIBO_CONFIG["access_token"]
weibo_sdk = WeiboOpenSdk()
uids = [1817472001, 2510431310]
ids = [4255226006923556, 4139327502165526]
q = "手机"

class WeiboOpenSdkTests(unittest.TestCase):

    def test_get_mid_from_url(self):
        url = "https://weibo.com/2510431310/GnaGct38g?from=page_1005052510431310_profile&wvr=6&mod=weibotime&type=comment#_rnd1530610606653"
        url2 = "https://weibo.com/2803301701/Fgv5s95lQ?from=embedded_weibo&type=comment"
        mid = weibo_sdk.get_mid_from_url(url)
        # print(mid)

    def test_get_id_from_mid(self):
        mid = "Fgv5s95lQ"
        id = weibo_sdk.get_id_from_mid(mid)
        # print(id)

    def test_statuses_show(self):
        statuses_show = weibo_sdk.statuses_count(ids=[4255226006923556], access_token=ACCESS_TOKEN)
        print(statuses_show.text)

    def test_statuses_all(self):
        ids = [4255226006923556]
        statuses_all = weibo_sdk.statuses_all(id=ids, access_token=ACCESS_TOKEN)
        pprint(statuses_all)

    def test_statuses_count(self):
        status_count = weibo_sdk.statuses_count(ids=[4255226006923556, 4139327502165526], access_token=ACCESS_TOKEN)
        print(status_count.text)

    def test_user_counts(self):
        user_counts = weibo_sdk.user_counts(ACCESS_TOKEN, 2510431310)
        # print(user_counts.text)

    def test_comments_show(self):
        ids = [4255226006923556]
        comments_show = weibo_sdk.comments_show(id=ids, access_token=ACCESS_TOKEN)
        pprint(json.loads(comments_show.text))

    def test_friendships_friends(self):
        # 不是授权用户，无法获得数据
        uid = 1817472001
        friendships = weibo_sdk.friendships_friends(access_token=ACCESS_TOKEN, uid=uid)
        # pprint(friendships.json())

    def test_friendships_friends_ids(self):
        # 不是授权用户，无法获取数据
        uid = 1817472001
        friendships = weibo_sdk.friendships_friends_ids(access_token=ACCESS_TOKEN, uid=uid)
        # print(friendships.json())

    def test_friendships_followers(self):
        # 不是授权用户， 无法获取数据
        uid = 1817472001
        friendships_followers = weibo_sdk.friendships_followers(access_token=ACCESS_TOKEN, uid=uid)
        # pprint(friendships_followers.json())

    def test_friendships_followers_ids(self):
        # 不是授权用户，无法获得数据
        uid = 1817472001
        friendships_followers_ids = weibo_sdk.friendships_friends_ids(access_token=ACCESS_TOKEN, uid=uid)
        # pprint(friendships_followers_ids.json())

    def test_search_topics(self):
        # 应用权限访问权限受限制
        q = "手机"
        search_topics = weibo_sdk.search_topics(access_token=ACCESS_TOKEN, q=q)
        # print(search_topics.text)

    def test_statuses_user_timeline_batch(self):
        statues_user_timeline_batch = weibo_sdk.statuses_user_timeline_batch(access_token=ACCESS_TOKEN, uids=uids)
        # pprint(statues_user_timeline_batch.json())

    def test_tags_batch_other(self):
        tags_batch_other = weibo_sdk.tags_batch_other(uids=uids, access_token=ACCESS_TOKEN)
        # print(tags_batch_other.json())

    def test_users_show_batch_other(self):
        user_show_batch_other = weibo_sdk.users_show_batch_other(access_token=ACCESS_TOKEN, uids=uids)
        # pprint(user_show_batch_other.json())

    def test_search_statuses_limited(self):
        search_statuses_limited = weibo_sdk.search_statuses_limited(access_token=ACCESS_TOKEN, q=q)
        pprint(search_statuses_limited.json())


if __name__ == '__main__':
    unittest.main()